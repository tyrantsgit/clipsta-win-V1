@echo off
:: build.bat — builds wasapi-capture.exe
:: Run from a Visual Studio Developer Command Prompt (any edition, 2019+)
:: or from the MSYS2/MinGW-w64 shell.
::
:: Output: wasapi-capture.exe (copy into your Clipsta bin/ directory)

where cl >nul 2>&1
if %ERRORLEVEL% EQU 0 (
    echo [build] Using MSVC
    cl /EHsc /O2 /W3 /nologo ^
        wasapi-capture.cpp ^
        /Fe:wasapi-capture.exe ^
        ole32.lib oleaut32.lib uuid.lib avrt.lib
    if %ERRORLEVEL% NEQ 0 (
        echo [build] MSVC build FAILED
        exit /b 1
    )
) else (
    where g++ >nul 2>&1
    if %ERRORLEVEL% EQU 0 (
        echo [build] Using MinGW-w64 g++
        g++ -O2 -std=c++17 -Wall ^
            wasapi-capture.cpp ^
            -o wasapi-capture.exe ^
            -lole32 -loleaut32 -luuid -lavrt
        if %ERRORLEVEL% NEQ 0 (
            echo [build] MinGW build FAILED
            exit /b 1
        )
    ) else (
        echo [build] ERROR: Neither cl.exe nor g++ found.
        echo         Open a Visual Studio Developer Command Prompt, or install
        echo         MinGW-w64 via MSYS2 (pacman -S mingw-w64-x86_64-gcc).
        exit /b 1
    )
)

echo.
echo [build] Success: wasapi-capture.exe
echo [build] Copy it to clipsta-win-V1/bin/wasapi-capture.exe
echo         (or place it next to ffmpeg.exe in the packaged app resources)
