// wasapi-capture.cpp
// Clipsta WASAPI Loopback Capture
//
// Implements OBS's exact audio capture technique:
//   IAudioClient::Initialize with AUDCLNT_STREAMFLAGS_LOOPBACK
// against the system's default render endpoint (speakers/headphones).
// This captures desktop/game audio from ALL applications with no
// dependency on Stereo Mix, virtual audio cables, or any third-party
// software — the same reason OBS "Desktop Audio" works universally.
//
// Usage:
//   wasapi-capture.exe <named-pipe-path>
//   e.g. wasapi-capture.exe \\.\pipe\clipsta-audio-1234
//
// Output:
//   Raw PCM — signed 16-bit little-endian, stereo, 48000 Hz
//   written into the named pipe for ffmpeg to consume:
//   ffmpeg -f s16le -ar 48000 -ac 2 -i \\.\pipe\clipsta-audio-1234 ...
//
// Build (MSVC, from a Visual Studio Developer Command Prompt):
//   cl /EHsc /O2 /W3 wasapi-capture.cpp /Fe:wasapi-capture.exe ^
//      ole32.lib oleaut32.lib uuid.lib avrt.lib
//
// Build (MinGW-w64 / MSYS2):
//   g++ -O2 -std=c++17 wasapi-capture.cpp -o wasapi-capture.exe ^
//      -lole32 -loleaut32 -luuid -lavrt

#define WIN32_LEAN_AND_MEAN
#define NOMINMAX
#include <windows.h>
#include <mmdeviceapi.h>
#include <audioclient.h>
#include <avrt.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <math.h>

// ── WASAPI interface GUIDs ────────────────────────────────────────────────────
// Defined here so we don't need the Windows SDK's uuid.lib in all build
// configurations; the values are stable and documented in the Windows SDK.
DEFINE_GUID(CLSID_MMDeviceEnumerator,
    0xBCDE0395, 0xE52F, 0x467C, 0x8E, 0x3D, 0xC4, 0x57, 0x92, 0x91, 0x69, 0x2E);
DEFINE_GUID(IID_IMMDeviceEnumerator,
    0xA95664D2, 0x9614, 0x4F35, 0xA7, 0x46, 0xDE, 0x8D, 0xB6, 0x36, 0x17, 0xE6);
DEFINE_GUID(IID_IAudioClient,
    0x1CB9AD4C, 0xDBFA, 0x4c32, 0xB1, 0x78, 0xC2, 0xF5, 0x68, 0xA7, 0x03, 0xB2);
DEFINE_GUID(IID_IAudioCaptureClient,
    0xC8ADBD64, 0xE71E, 0x48a0, 0xA4, 0xDE, 0x18, 0x5C, 0x39, 0x5C, 0xD3, 0x17);

// Target output format: s16le stereo 48000 Hz — matches ffmpeg's expected input
static const UINT32  TARGET_SAMPLE_RATE  = 48000;
static const UINT16  TARGET_CHANNELS     = 2;
static const UINT16  TARGET_BITS         = 16;
static const UINT32  TARGET_BLOCK_ALIGN  = TARGET_CHANNELS * (TARGET_BITS / 8);
static const UINT32  TARGET_AVG_BYTES    = TARGET_SAMPLE_RATE * TARGET_BLOCK_ALIGN;

// WASAPI buffer duration: 20ms — OBS default for loopback capture
static const REFERENCE_TIME BUFFER_DURATION = 200000; // 100ns units

// ── Silence detection threshold for loopback silence-frame injection ─────────
// WASAPI loopback returns 0 frames when the audio engine is idle (no app
// playing sound). We must inject silence in that gap or ffmpeg's A/V sync
// drifts. This is exactly what OBS's win-wasapi plugin does.
static void WriteSilence(HANDLE hPipe, UINT32 nFrames, UINT16 nChannels) {
    size_t bytes = (size_t)nFrames * nChannels * sizeof(int16_t);
    if (!bytes) return;
    // Stack-allocate up to 4KB, heap otherwise
    int16_t* buf = (bytes <= 4096)
        ? (int16_t*)_alloca(bytes)
        : (int16_t*)calloc(1, bytes);
    if (!buf) return;
    memset(buf, 0, bytes);
    DWORD written = 0;
    WriteFile(hPipe, buf, (DWORD)bytes, &written, nullptr);
    if (bytes > 4096) free(buf);
}

// ── Float32 → S16LE conversion ───────────────────────────────────────────────
// WASAPI typically delivers WAVEFORMATEXTENSIBLE with IEEE_FLOAT subtype.
// ffmpeg wants s16le. Clamp to [-1, 1] then scale to INT16 range.
static inline int16_t Float32ToS16(float f) {
    f = f < -1.0f ? -1.0f : (f > 1.0f ? 1.0f : f);
    return (int16_t)(f * 32767.0f);
}

static void ConvertAndWrite(HANDLE hPipe,
                             const BYTE* pData,
                             UINT32 nFrames,
                             UINT16 srcChannels,
                             bool isSigned16,
                             bool isFloat32) {
    if (!nFrames) return;

    // Output buffer: TARGET_CHANNELS s16le per frame
    size_t outBytes = (size_t)nFrames * TARGET_BLOCK_ALIGN;
    int16_t* out = (outBytes <= 4096)
        ? (int16_t*)_alloca(outBytes)
        : (int16_t*)malloc(outBytes);
    if (!out) return;

    for (UINT32 f = 0; f < nFrames; f++) {
        for (UINT16 c = 0; c < TARGET_CHANNELS; c++) {
            // Map channel index; if source has fewer channels, use channel 0
            UINT16 srcC = (c < srcChannels) ? c : 0;

            int16_t sample = 0;
            if (isFloat32) {
                const float* fSrc = (const float*)pData;
                sample = Float32ToS16(fSrc[f * srcChannels + srcC]);
            } else if (isSigned16) {
                const int16_t* sSrc = (const int16_t*)pData;
                sample = sSrc[f * srcChannels + srcC];
            }
            out[f * TARGET_CHANNELS + c] = sample;
        }
    }

    DWORD written = 0;
    WriteFile(hPipe, out, (DWORD)outBytes, &written, nullptr);
    if (outBytes > 4096) free(out);
}

// ── Error helpers ─────────────────────────────────────────────────────────────
static void FatalHR(const char* msg, HRESULT hr) {
    fprintf(stderr, "[wasapi-capture] %s: HRESULT 0x%08lX\n", msg, (unsigned long)hr);
    ExitProcess(1);
}

// ── Main ─────────────────────────────────────────────────────────────────────
int main(int argc, char** argv) {
    if (argc < 2) {
        fprintf(stderr, "Usage: wasapi-capture.exe <named-pipe-path>\n");
        fprintf(stderr, "  e.g. wasapi-capture.exe \\\\.\\pipe\\clipsta-audio-1234\n");
        return 1;
    }
    const char* pipePath = argv[1];

    // ── Create named pipe server ──────────────────────────────────────────
    // We create the pipe; ffmpeg (our client) will connect and read from it.
    // PIPE_TYPE_BYTE | PIPE_READMODE_BYTE for streaming PCM.
    HANDLE hPipe = CreateNamedPipeA(
        pipePath,
        PIPE_ACCESS_OUTBOUND,                          // write only
        PIPE_TYPE_BYTE | PIPE_WAIT,
        1,                                             // max instances
        1024 * 1024,                                   // out buffer 1 MB
        0,
        5000,                                          // timeout ms
        nullptr
    );
    if (hPipe == INVALID_HANDLE_VALUE) {
        fprintf(stderr, "[wasapi-capture] CreateNamedPipe failed: %lu\n", GetLastError());
        return 1;
    }
    fprintf(stderr, "[wasapi-capture] Pipe created: %s — waiting for ffmpeg...\n", pipePath);

    // Block until ffmpeg connects
    if (!ConnectNamedPipe(hPipe, nullptr)) {
        DWORD err = GetLastError();
        // ERROR_PIPE_CONNECTED means client already connected before we called this
        if (err != ERROR_PIPE_CONNECTED) {
            fprintf(stderr, "[wasapi-capture] ConnectNamedPipe failed: %lu\n", err);
            CloseHandle(hPipe);
            return 1;
        }
    }
    fprintf(stderr, "[wasapi-capture] ffmpeg connected — starting WASAPI loopback capture\n");

    // ── Set this thread to Audio class for lower scheduling latency ───────
    // OBS does the same in win-wasapi. Without this, the OS can pre-empt
    // the capture thread mid-packet resulting in gaps.
    DWORD taskIndex = 0;
    HANDLE hTask = AvSetMmThreadCharacteristicsA("Audio", &taskIndex);

    // ── COM init ──────────────────────────────────────────────────────────
    HRESULT hr = CoInitializeEx(nullptr, COINIT_MULTITHREADED);
    if (FAILED(hr)) FatalHR("CoInitializeEx", hr);

    // ── Get default render endpoint (speakers/headphones) ─────────────────
    // LOOPBACK captures whatever the render endpoint is playing —
    // this is why it works for all applications without Stereo Mix.
    IMMDeviceEnumerator* pEnum = nullptr;
    hr = CoCreateInstance(CLSID_MMDeviceEnumerator, nullptr, CLSCTX_ALL,
                          IID_IMMDeviceEnumerator, (void**)&pEnum);
    if (FAILED(hr)) FatalHR("CoCreateInstance(MMDeviceEnumerator)", hr);

    IMMDevice* pDevice = nullptr;
    hr = pEnum->GetDefaultAudioEndpoint(eRender, eConsole, &pDevice);
    if (FAILED(hr)) FatalHR("GetDefaultAudioEndpoint", hr);
    pEnum->Release();

    // ── Initialise IAudioClient in LOOPBACK mode ──────────────────────────
    IAudioClient* pClient = nullptr;
    hr = pDevice->Activate(IID_IAudioClient, CLSCTX_ALL, nullptr, (void**)&pClient);
    if (FAILED(hr)) FatalHR("IMMDevice::Activate(IAudioClient)", hr);
    pDevice->Release();

    // Get the mix format — this tells us what bit depth / channel count the
    // audio engine is actually running at so we can convert correctly.
    WAVEFORMATEX* pMixFmt = nullptr;
    hr = pClient->GetMixFormat(&pMixFmt);
    if (FAILED(hr)) FatalHR("GetMixFormat", hr);

    // Determine source format
    bool isSigned16 = false;
    bool isFloat32  = false;
    UINT16 srcChannels = pMixFmt->nChannels;

    if (pMixFmt->wFormatTag == WAVE_FORMAT_IEEE_FLOAT) {
        isFloat32 = true;
    } else if (pMixFmt->wFormatTag == WAVE_FORMAT_EXTENSIBLE) {
        WAVEFORMATEXTENSIBLE* pExt = (WAVEFORMATEXTENSIBLE*)pMixFmt;
        // KSDATAFORMAT_SUBTYPE_IEEE_FLOAT
        static const GUID KSDATAFORMAT_SUBTYPE_IEEE_FLOAT_GUID =
            {0x00000003, 0x0000, 0x0010,
             {0x80, 0x00, 0x00, 0xAA, 0x00, 0x38, 0x9B, 0x71}};
        // KSDATAFORMAT_SUBTYPE_PCM
        static const GUID KSDATAFORMAT_SUBTYPE_PCM_GUID =
            {0x00000001, 0x0000, 0x0010,
             {0x80, 0x00, 0x00, 0xAA, 0x00, 0x38, 0x9B, 0x71}};
        if (IsEqualGUID(pExt->SubFormat, KSDATAFORMAT_SUBTYPE_IEEE_FLOAT_GUID))
            isFloat32 = true;
        else if (IsEqualGUID(pExt->SubFormat, KSDATAFORMAT_SUBTYPE_PCM_GUID)
                 && pMixFmt->wBitsPerSample == 16)
            isSigned16 = true;
    } else if (pMixFmt->wFormatTag == WAVE_FORMAT_PCM
               && pMixFmt->wBitsPerSample == 16) {
        isSigned16 = true;
    }

    fprintf(stderr,
        "[wasapi-capture] Mix format: %u Hz, %u ch, %u bit, float=%d pcm16=%d\n",
        pMixFmt->nSamplesPerSec, srcChannels, pMixFmt->wBitsPerSample,
        (int)isFloat32, (int)isSigned16);

    // AUDCLNT_STREAMFLAGS_LOOPBACK — the core of the OBS audio method.
    // Captures the render endpoint's output mix (everything playing through
    // speakers/headphones) regardless of which application produced it.
    hr = pClient->Initialize(
        AUDCLNT_SHAREMODE_SHARED,
        AUDCLNT_STREAMFLAGS_LOOPBACK,
        BUFFER_DURATION,
        0,
        pMixFmt,
        nullptr
    );
    if (FAILED(hr)) FatalHR("IAudioClient::Initialize (LOOPBACK)", hr);

    UINT32 bufferFrames = 0;
    hr = pClient->GetBufferSize(&bufferFrames);
    if (FAILED(hr)) FatalHR("GetBufferSize", hr);

    IAudioCaptureClient* pCapture = nullptr;
    hr = pClient->GetService(IID_IAudioCaptureClient, (void**)&pCapture);
    if (FAILED(hr)) FatalHR("GetService(IAudioCaptureClient)", hr);

    hr = pClient->Start();
    if (FAILED(hr)) FatalHR("IAudioClient::Start", hr);

    fprintf(stderr, "[wasapi-capture] Capture running — streaming to ffmpeg\n");

    // ── Capture loop ──────────────────────────────────────────────────────
    // OBS's win-wasapi plugin polls at half the buffer duration.
    // We do the same: sleep ~10ms, then drain all available packets.
    // AUDCLNT_BUFFERFLAGS_SILENT = audio engine has no data (app is quiet)
    // — we inject silence frames to maintain A/V sync, just like OBS does.
    UINT32 srcSampleRate = pMixFmt->nSamplesPerSec;
    CoTaskMemFree(pMixFmt);

    while (true) {
        Sleep(10); // half of 20ms buffer

        UINT32 packetSize = 0;
        hr = pCapture->GetNextPacketSize(&packetSize);
        if (FAILED(hr)) break;

        while (packetSize > 0) {
            BYTE*  pData   = nullptr;
            UINT32 nFrames = 0;
            DWORD  flags   = 0;
            UINT64 devPos  = 0, qpcPos = 0;

            hr = pCapture->GetBuffer(&pData, &nFrames, &flags, &devPos, &qpcPos);
            if (FAILED(hr)) { packetSize = 0; break; }

            if (flags & AUDCLNT_BUFFERFLAGS_SILENT) {
                // Audio engine is idle — inject silence to keep A/V sync
                // scaled to our output sample rate
                UINT32 silentFrames = (UINT32)((UINT64)nFrames
                    * TARGET_SAMPLE_RATE / srcSampleRate);
                WriteSilence(hPipe, silentFrames, TARGET_CHANNELS);
            } else {
                ConvertAndWrite(hPipe, pData, nFrames,
                                srcChannels, isSigned16, isFloat32);
            }

            pCapture->ReleaseBuffer(nFrames);

            hr = pCapture->GetNextPacketSize(&packetSize);
            if (FAILED(hr)) packetSize = 0;
        }

        // If the pipe broke (ffmpeg exited), stop cleanly
        if (GetLastError() == ERROR_BROKEN_PIPE) break;
    }

    // ── Cleanup ───────────────────────────────────────────────────────────
    pClient->Stop();
    pCapture->Release();
    pClient->Release();
    CoUninitialize();
    if (hTask) AvRevertMmThreadCharacteristics(hTask);
    CloseHandle(hPipe);

    fprintf(stderr, "[wasapi-capture] Exiting\n");
    return 0;
}
