
# Clipsta Recording Engine

**Correction from earlier doc:** this app does not link against libobs/obs.dll
and does not contain a native C++ bridge. An earlier revision's
`electron/main/obs/ObsBackend.ts` claimed an "OBS engine" but was a stub —
`startReplayBuffer()`/`saveReplay()` returned hardcoded success objects
without touching ffmpeg, OBS, or disk. It has been removed, along with the
renderer calls (`startOBSRecording`/`stopOBSRecording`/`saveOBSClip`) that
referenced preload methods that were never actually exposed — clicking
Record would throw immediately.

## What's actually implemented

`electron/main/captureEngine.ts` ports the *technique* OBS's own
replay-buffer module uses, built on ffmpeg (already bundled), not on libobs:

- **Capture**: `ddagrab` (DXGI Desktop Duplication — the same GPU-side API
  OBS's "Display Capture" source and NVIDIA ShadowPlay use) is tried first,
  auto-detected against the bundled ffmpeg build, with automatic fallback to
  `gdigrab` (CPU/GDI) if unavailable or if it fails at runtime.
- **Encoder**: auto-detects NVENC → QuickSync → AMF → x264 in that order
  (mirroring OBS's own hardware-encoder priority), with automatic runtime
  fallback down the chain if a hardware encoder fails to initialize on a
  machine it was compiled for but isn't actually present in.
- **Replay buffer**: continuous capture into fixed-length, GOP-aligned
  segments (forced keyframe at every segment boundary), so any trailing
  window of segments is independently decodable and can be stream-copy
  concatenated into a clip instantly — the same guarantee libobs gives its
  GOPs, without re-encoding.
- **Smoothness**: `-fps_mode cfr` locks output to a constant frame rate so
  variable capture timing doesn't read as stutter on playback.

## Genuine libobs integration — not implemented

A real libobs integration would mean a native Node addon compiled against
the actual OBS SDK with MSVC, calling real functions like `obs_startup()`,
`obs_encoder_create()`, `obs_output_create("replay_buffer", ...)`, and
shipping `obs.dll`/`obs-plugins` alongside the app. That's a legitimate,
large undertaking, and it requires a Windows build environment to write,
compile, and verify — it has not been attempted here.
