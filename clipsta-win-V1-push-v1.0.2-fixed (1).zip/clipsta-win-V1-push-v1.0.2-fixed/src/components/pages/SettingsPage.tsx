import { useEffect, useRef, useState } from "react";
import { QRCodeSVG } from "qrcode.react";
import { Save, FolderOpen, RotateCcw, Keyboard, Monitor, Volume2, Cpu, HardDrive, Cloud, Upload, Loader2, X, Smartphone, Link2Off } from "lucide-react";
import type { AppSettings } from "../../types";
import { DEFAULTS } from "../../hooks/useSettings";
import type { useCloudUpload } from "../../hooks/useCloudUpload";

interface Props {
	settings: AppSettings;
	updateSetting: <K extends keyof AppSettings>(key: K, value: AppSettings[K]) => void;
	saveAll: (s: AppSettings) => Promise<void>;
	cloud: ReturnType<typeof useCloudUpload>;
}

export default function SettingsPage({ settings, updateSetting, saveAll, cloud }: Props) {
	const [local, setLocal] = useState<AppSettings>({ ...settings });
	const [audioInputs, setAudioInputs] = useState<string[]>([]);
	const [liveAudioDiag, setLiveAudioDiag] = useState<{ wasapiActive: boolean; micAudioDeviceName: string | null; allDevices: string[] } | null>(null);

	useEffect(() => {
		window.clipsta?.listCaptureAudioDevices?.().then(setAudioInputs).catch(() => setAudioInputs([]));
		window.clipsta?.onAudioDevicesResolved?.((data: any) => {
			setLiveAudioDiag(data);
			if (data.allDevices) setAudioInputs(data.allDevices);
		});
	}, []);
	const [saved, setSaved] = useState(false);
	const [showPairingModal, setShowPairingModal] = useState(false);
	const [justPaired, setJustPaired] = useState(false);

	// Show paired animation when pairingConfirmed becomes true
	useEffect(() => {
		if (cloud.pairingConfirmed) {
			setJustPaired(true);
			const t = setTimeout(() => setJustPaired(false), 4000);
			return () => clearTimeout(t);
		}
	}, [cloud.pairingConfirmed]);

	const update = <K extends keyof AppSettings>(key: K, value: AppSettings[K]) => {
		setLocal((prev) => ({ ...prev, [key]: value }));
	};

	const handleSave = async () => {
		await saveAll(local);
		setSaved(true);
		setTimeout(() => setSaved(false), 2500);
	};

	const browseFolder = async () => {
		const folder = await window.clipsta?.browseFolder();
		if (folder) update("outputFolder", folder);
	};

	return (
		<div className="h-full overflow-y-auto p-6 max-w-3xl mx-auto">
			<div className="flex items-center justify-between mb-6">
				<div>
					<h1 className="text-2xl font-black text-white">Settings</h1>
					<p className="text-text-dim text-sm mt-0.5">Configure recording, hotkeys and export</p>
				</div>
				<div className="flex items-center gap-3">
					<button onClick={() => setLocal({ ...DEFAULTS })} className="btn-ghost">
						<RotateCcw size={14} /> Reset Defaults
					</button>
					<button onClick={handleSave} className="btn-y">
						<Save size={14} />
						{saved ? "Saved ✓" : "Save Settings"}
					</button>
				</div>
			</div>

			<div className="space-y-6">

				{/* ── Hotkeys ── */}
				<Section icon={<Keyboard size={16} />} title="Hotkeys">
					<p className="text-text-dim text-xs mb-3">
						These work globally even when the app is minimized. Use modifiers like Alt, Ctrl, Shift.
					</p>
					<div className="grid grid-cols-3 gap-4">
						<HotkeyField label="Start / Stop Recording" value={local.hotkeyRecord}
							onChange={(v) => update("hotkeyRecord", v)} />
						<HotkeyField label="Save Last 1 Minute" value={local.hotkeyClip1Min}
							onChange={(v) => update("hotkeyClip1Min", v)} />
						<HotkeyField label="Save Last 5 Minutes" value={local.hotkeyClip5Min}
							onChange={(v) => update("hotkeyClip5Min", v)} />
					</div>
					<p className="text-text-dim text-[10px] mt-2">
						Examples: F9, Alt+F9, Ctrl+Shift+R. The 1-min and 5-min keys save from the rolling buffer while recording.
					</p>
				</Section>

				{/* ── Video ── */}
				<Section icon={<Monitor size={16} />} title="Video">
					<div className="grid grid-cols-2 gap-4">
						<SelectField label="Resolution" value={local.resolution}
							onChange={(v) => update("resolution", v)}
							options={["480p", "720p", "1080p", "1440p", "4k"]} />
						<SelectField label="Frame Rate" value={String(local.fps)}
							onChange={(v) => update("fps", Number(v))}
							options={["30", "60", "120"]} />
						<SelectField label="Encoder" value={local.encoder}
							onChange={(v) => update("encoder", v)}
							options={["auto", "x264 (Software)", "HEVC (H.265)", "NVENC (NVIDIA)", "AMF (AMD)", "QuickSync (Intel)"]} />
						<SelectField label="Aspect Ratio" value={local.aspectRatio}
							onChange={(v) => update("aspectRatio", v)}
							options={["16:9", "9:16", "4:3", "21:9"]} />
						<NumberField label="Video Bitrate (kbps)" value={local.bitrate}
							onChange={(v) => update("bitrate", v)} min={1000} max={100000} step={1000} />
						<SelectField label="Buffer Duration" value={String(local.bufferDuration)}
							onChange={(v) => update("bufferDuration", Number(v))}
							options={["30", "60", "120", "180", "300"]}
							display={(v) => v === "60" ? "1 minute" : v === "300" ? "5 minutes" : `${v}s`} />
					</div>
				</Section>

				{/* ── Audio ── */}
				<Section icon={<Volume2 size={16} />} title="Audio">
					<div className="grid grid-cols-2 gap-4">
						<SelectField label="Audio Source" value={local.audioSource}
							onChange={(v) => update("audioSource", v)}
							options={["desktop", "mic", "both", "none"]}
							display={(v) =>
								v === "desktop" ? "Desktop Audio (system)" :
								v === "mic" ? "Microphone only" :
								v === "both" ? "Desktop + Microphone" : "None"} />
						<NumberField label="Audio Bitrate (kbps)" value={local.audioBitrate}
							onChange={(v) => update("audioBitrate", v)} min={64} max={320} step={32} />
						{(local.audioSource === "mic" || local.audioSource === "both") && (
							<SelectField label="Microphone" value={local.audioInputDeviceId}
								onChange={(v) => update("audioInputDeviceId", v)}
								options={["", ...audioInputs]}
								display={(v) => (v === "" ? "System Default" : v)}
							/>
						)}
					</div>
					{(local.audioSource === "desktop" || local.audioSource === "both") && (
						<p className="text-text-dim text-[10px] mt-2">
							Desktop/game audio uses WASAPI loopback — captures all applications, no Stereo Mix needed.
						</p>
					)}
					{liveAudioDiag && (
						<div className="mt-2 p-2 rounded bg-white/5 text-[10px] text-text-dim space-y-0.5">
							<p className="text-white/60 font-medium">Last recording:</p>
							<p>Desktop audio: {liveAudioDiag.wasapiActive ? "✓ WASAPI loopback active" : "✗ wasapi-capture.exe not found — build from native/build.bat"}</p>
							<p>Mic: {liveAudioDiag.micAudioDeviceName ?? "none"}</p>
						</div>
					)}
				</Section>

				{/* ── Capture ── */}
				<Section icon={<Cpu size={16} />} title="Capture Behavior">
					<div className="grid grid-cols-2 gap-4">
						<SelectField label="Capture Mode" value={local.captureMode}
							onChange={(v) => update("captureMode", v)}
							options={["fullscreen", "region", "window"]}
							display={(v) =>
								v === "fullscreen" ? "Full Screen" :
								v === "region" ? "Region" :
								v === "window" ? "Window" : v} />
						<SelectField label="Segment Duration" value={String(local.segmentDuration)}
							onChange={(v) => update("segmentDuration", Number(v))}
							options={["5", "10", "30", "60"]}
							display={(v) => v === "60" ? "1 minute" : `${v}s`} />
						<Toggle label="Replay Buffer" checked={local.replayBufferEnabled}
							onChange={(v) => update("replayBufferEnabled", v)}
							description="Keep rolling buffer for instant clip saving" />
						{local.replayBufferEnabled && (
							<SelectField label="Replay Buffer Duration" value={String(local.replayBufferDuration)}
								onChange={(v) => update("replayBufferDuration", Number(v))}
								options={["30", "60", "120", "180", "300", "600"]}
								display={(v) => v === "60" ? "1 min" : v === "300" ? "5 mins" : v === "600" ? "10 mins" : `${v}s`} />
						)}
						<Toggle label="Auto Game Detection" checked={local.gameDetect}
							onChange={(v) => update("gameDetect", v)}
							description="Automatically capture the active fullscreen game" />
						<Toggle label="Minimize to System Tray" checked={local.minimizeToTray}
							onChange={(v) => update("minimizeToTray", v)}
							description="Keep running in tray when window is closed" />
						<Toggle label="Show Overlay" checked={local.overlayEnabled}
							onChange={(v) => update("overlayEnabled", v)}
							description="Recording indicator while capturing" />
					</div>
				</Section>

				{/* ── Cloud ── */}
				<Section icon={<Cloud size={16} />} title="Cloud Upload">
					<div className="grid grid-cols-2 gap-4">
						<Toggle label="Enable Cloud Upload" checked={local.cloudEnabled}
							onChange={(v) => update("cloudEnabled", v)}
							description="Upload clips to your paired mobile device" />
						<Toggle label="Auto-Upload New Clips" checked={local.autoUpload}
							onChange={(v) => update("autoUpload", v)}
							description="Automatically queue new recordings for upload" />
						<NumberField label="Upload Bandwidth (KB/s)" value={local.uploadBandwidth}
							onChange={(v) => update("uploadBandwidth", v)} min={0} max={50000} step={500} />
						<Toggle label="Delete After Upload" checked={local.deleteAfterUpload}
							onChange={(v) => update("deleteAfterUpload", v)}
							description="Remove local clip file after successful cloud upload" />
					</div>
					{local.cloudEnabled && (
						<div className="bg-muted rounded-lg p-3 space-y-2">
							<div className="flex items-center justify-between">
								<p className="text-xs text-text-dim font-semibold">Pairing</p>
								{cloud.pairingConfirmed ? (
									<span className={`text-[10px] text-green-400 font-bold ${justPaired ? "animate-pulse" : ""}`}>✓ Paired</span>
								) : cloud.paired ? (
									<span className="text-[10px] text-y-400 font-bold">Pending</span>
								) : (
									<span className="text-[10px] text-text-dim">Not paired</span>
								)}
							</div>
							{justPaired && (
								<div className="flex items-center gap-2 text-green-400 text-xs py-1 animate-fadeIn">
									<div className="w-5 h-5 rounded-full bg-green-500 flex items-center justify-center">
										<span className="text-black text-[10px] font-bold">✓</span>
									</div>
									<span>Paired successfully! Your clips can now be uploaded to the cloud.</span>
								</div>
							)}
							{cloud.pairingConfirmed && !justPaired && (
								<div className="text-center py-2">
									<p className="text-[10px] text-green-400">Device paired — ready to upload</p>
								</div>
							)}
							{cloud.paired && !cloud.pairingConfirmed && (
								<div className="text-center py-2">
									<p className="text-[10px] text-text-dim">Waiting for phone to scan QR code…</p>
								</div>
							)}
							<button
								onClick={() => {
									setShowPairingModal(true);
									cloud.generatePairingCode();
								}}
								className="btn-y w-full justify-center text-xs py-2"
							>
								<Smartphone size={12} /> Pair with iPhone
							</button>
							{cloud.paired && (
								<button
									onClick={() => {
										cloud.clearPairing();
										setShowPairingModal(false);
									}}
									className="btn-ghost w-full justify-center text-xs py-2 text-red-400 hover:text-red-300"
								>
									<Link2Off size={12} /> Unpair Device
								</button>
							)}
							{local.uploadBandwidth === 0 && (
								<p className="text-[10px] text-text-dim">Bandwidth: 0 = unlimited</p>
							)}
						</div>
					)}
				</Section>

				{/* ── Output ── */}
				<Section icon={<HardDrive size={16} />} title="Output">
					<div className="space-y-1">
						<p className="label">Clips Folder</p>
						<div className="flex gap-2">
							<input
								value={local.outputFolder}
								onChange={(e) => update("outputFolder", e.target.value)}
								className="input flex-1"
								placeholder="C:\Users\...\Videos\Clipsta"
							/>
							<button onClick={browseFolder} className="btn-ghost flex-shrink-0">
								<FolderOpen size={14} /> Browse
							</button>
							<button
								onClick={() => window.clipsta?.openFolder(local.outputFolder)}
								className="btn-ghost flex-shrink-0"
							>
								Open
							</button>
						</div>
					</div>
				</Section>

			</div>

			{/* Save bar */}
			<div className="sticky bottom-0 pt-6 pb-2 bg-gradient-to-t from-bg to-transparent">
				<button onClick={handleSave} className="btn-y w-full justify-center py-3 text-base">
					<Save size={18} />
					{saved ? "Settings Saved ✓" : "Save All Settings"}
				</button>
			</div>

			{/* Pairing QR modal */}
			{showPairingModal && (
				<div
					className="fixed inset-0 z-50 flex items-center justify-center bg-black/70"
					onClick={() => setShowPairingModal(false)}
				>
					<div
						className="bg-card rounded-xl p-8 max-w-sm w-full mx-4 shadow-2xl border border-border"
						onClick={(e) => e.stopPropagation()}
					>
						<div className="flex items-center justify-between mb-4">
							<h3 className="text-white font-bold text-lg">Pair with iPhone</h3>
							<button onClick={() => setShowPairingModal(false)} className="text-text-dim hover:text-white transition-colors">
								<X size={18} />
							</button>
						</div>

						{cloud.pairingLoading && (
							<div className="text-center py-10">
								<Loader2 size={32} className="animate-spin text-y mx-auto mb-3" />
								<p className="text-text-dim text-sm">Generating pairing code…</p>
							</div>
						)}

						{cloud.pairingUrl && !cloud.pairingLoading && (
							<div className="text-center space-y-4">
								<div className="flex justify-center">
									<QRCodeSVG
										value={cloud.pairingUrl}
										size={200}
										bgColor="transparent"
										fgColor="#D4F000"
									/>
								</div>
								<p className="text-text-dim text-xs">Open the Clipsta app on your iPhone and scan this QR code</p>
								<div className="flex items-center justify-center gap-2 text-[10px] text-text-dim">
									<span className="w-1.5 h-1.5 rounded-full bg-y animate-pulse" />
									Waiting for phone to connect…
								</div>
								<button
									onClick={() => {
										cloud.confirmPairing();
										setShowPairingModal(false);
									}}
									className="btn-y w-full justify-center text-xs py-2 mt-2"
								>
									Done — I've scanned the code
								</button>
							</div>
						)}

						{cloud.pairingError && !cloud.pairingLoading && (
							<div className="text-center py-6 space-y-3">
								<p className="text-red-400 text-sm">{cloud.pairingError}</p>
								<button
									onClick={() => {
										cloud.generatePairingCode();
									}}
									className="btn-y w-full justify-center text-xs py-2"
								>
									Retry
								</button>
							</div>
						)}
					</div>
				</div>
			)}
		</div>
	);
}

function Section({ icon, title, children }: { icon: React.ReactNode; title: string; children: React.ReactNode }) {
	return (
		<div className="card p-5 space-y-4">
			<div className="flex items-center gap-2 border-b border-border pb-3">
				<span className="text-y">{icon}</span>
				<h3 className="font-bold text-white">{title}</h3>
			</div>
			{children}
		</div>
	);
}

function HotkeyField({ label, value, onChange }: { label: string; value: string; onChange: (v: string) => void }) {
	const [capturing, setCapturing] = useState(false);
	const [keys, setKeys] = useState<string[]>([]);
	const inputRef = useRef<HTMLInputElement>(null);

	const startCapture = () => {
		setKeys([]);
		setCapturing(true);
		setTimeout(() => inputRef.current?.focus(), 50);
	};

	const handleKeyDown = (e: React.KeyboardEvent) => {
		e.preventDefault();
		e.stopPropagation();
		const parts: string[] = [];
		if (e.ctrlKey || e.key === "Control") parts.push("Ctrl");
		if (e.altKey || e.key === "Alt") parts.push("Alt");
		if (e.shiftKey || e.key === "Shift") parts.push("Shift");
		if (e.metaKey || e.key === "Meta") parts.push("Super");
		const mods = ["Control", "Alt", "Shift", "Meta"];
		if (!mods.includes(e.key)) {
			const key = e.key.length === 1 ? e.key.toUpperCase() : e.key;
			parts.push(key);
		}
		setKeys(parts);
		if (!mods.includes(e.key) && parts.length > 0) {
			const combo = parts.join("+");
			onChange(combo);
			setCapturing(false);
		}
	};

	const displayValue = capturing ? (keys.length > 0 ? keys.join("+") : "Press keys...") : (value || "Click to set");

	return (
		<div className="space-y-1">
			<p className="label">{label}</p>
			{capturing ? (
				<input
					ref={inputRef}
					className="input font-mono text-y text-center"
					placeholder="Press keys..."
					value={displayValue}
					onKeyDown={handleKeyDown}
					onBlur={() => setCapturing(false)}
					readOnly
				/>
			) : (
				<button
					onClick={startCapture}
					className="input font-mono text-y text-center cursor-pointer hover:border-y w-full"
				>
					{displayValue}
				</button>
			)}
		</div>
	);
}

function SelectField({ label, value, onChange, options, display }: {
	label: string; value: string; onChange: (v: string) => void;
	options: string[]; display?: (v: string) => string;
}) {
	return (
		<div className="space-y-1">
			<p className="label">{label}</p>
			<select value={value} onChange={(e) => onChange(e.target.value)} className="input no-drag">
				{options.map((o) => <option key={o} value={o}>{display ? display(o) : o}</option>)}
			</select>
		</div>
	);
}

function NumberField({ label, value, onChange, min, max, step }: {
	label: string; value: number; onChange: (v: number) => void; min: number; max: number; step: number;
}) {
	return (
		<div className="space-y-1">
			<p className="label">{label}</p>
			<div className="flex items-center gap-2">
				<input
					type="range" min={min} max={max} step={step} value={value}
					onChange={(e) => onChange(Number(e.target.value))}
					className="flex-1 accent-[#D4F000] no-drag"
				/>
				<span className="text-white text-sm font-mono w-16 text-right">{value.toLocaleString()}</span>
			</div>
		</div>
	);
}

function Toggle({ label, checked, onChange, description }: {
	label: string; checked: boolean; onChange: (v: boolean) => void; description?: string;
}) {
	return (
		<label className="flex items-start gap-3 cursor-pointer group">
			<div
				onClick={() => onChange(!checked)}
				className={`mt-0.5 w-10 h-5 rounded-full flex-shrink-0 transition-colors relative cursor-pointer
					${checked ? "bg-y" : "bg-muted"}`}
			>
				<div className={`absolute top-0.5 w-4 h-4 rounded-full bg-black transition-transform
					${checked ? "translate-x-5" : "translate-x-0.5"}`} />
			</div>
			<div>
				<p className="text-sm text-white font-medium group-hover:text-y transition-colors">{label}</p>
				{description && <p className="text-text-dim text-xs mt-0.5">{description}</p>}
			</div>
		</label>
	);
}
