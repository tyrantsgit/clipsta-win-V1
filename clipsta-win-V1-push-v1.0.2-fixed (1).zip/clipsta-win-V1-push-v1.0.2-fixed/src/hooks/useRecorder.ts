import { useCallback, useEffect, useRef, useState } from "react";
import type { AppSettings } from "../types";

export type RecordState = "idle" | "recording" | "saving";

export interface RecorderState {
	status: RecordState;
	duration: number;
	savedPath: string | null;
	error: string | null;
	bufferSeconds: number;
}

// ─────────────────────────────────────────────────────────────────────────────
// FIX: this hook previously called window.clipsta.startOBSRecording /
// stopOBSRecording / saveOBSClip — none of which preload ever exposed (it
// only exposes startFFmpegRecording / stopFFmpegRecording / saveFFmpegClip).
// Calling a non-existent method on the bridge throws immediately, so
// clicking Record crashed on the spot. This now calls the methods that
// actually exist, which are backed by captureEngine.ts (ddagrab/gdigrab +
// GOP-aligned replay buffer — see OBS_ENGINE_MIGRATION.md).
// ─────────────────────────────────────────────────────────────────────────────

export function useRecorder(settings: AppSettings | null) {
	const [state, setState] = useState<RecorderState>({
		status: "idle",
		duration: 0,
		savedPath: null,
		error: null,
		bufferSeconds: 0,
	});

	const timerRef = useRef<ReturnType<typeof setInterval> | null>(null);
	const durationRef = useRef(0);
	const sourceIdRef = useRef<string | null>(null);

	const startRecording = useCallback(async (_sourceId: string | null = null) => {
		setState((s) => ({ ...s, error: null }));
		try {
			setState((s) => ({ ...s, status: "recording" }));
			durationRef.current = 0;

			const result = await window.clipsta?.startFFmpegRecording({
				segmentDuration: settings?.segmentDuration ?? 4,
				resolution: settings?.resolution ?? "1080p",
				bitrate: settings?.bitrate ?? 50000,
				encoder: settings?.encoder ?? "auto",
				fps: settings?.fps ?? 60,
				audioSource: settings?.audioSource ?? "desktop",
				captureMode: settings?.captureMode ?? "fullscreen",
			});

			if (result) {
				window.clipsta?.setRecordingState(true);
				timerRef.current = setInterval(() => {
					durationRef.current++;
					setState((s) => ({ ...s, duration: durationRef.current }));
				}, 1000);
			} else {
				setState((s) => ({ ...s, status: "idle", error: "Recording failed to start" }));
			}
		} catch (err: any) {
			setState((s) => ({
				...s,
				status: "idle",
				error: err.message ?? "Recording failed to start",
			}));
		}
	}, [settings]);

	const stopRecording = useCallback(async () => {
		if (timerRef.current) clearInterval(timerRef.current);
		timerRef.current = null;
		durationRef.current = 0;
		setState((s) => ({ ...s, status: "idle", duration: 0 }));
		await window.clipsta?.stopFFmpegRecording();
		window.clipsta?.setRecordingState(false);
	}, []);

	const saveClip = useCallback(async (seconds: number): Promise<string | null> => {
		setState((s) => ({ ...s, status: "saving", error: null }));
		try {
			const savedPath = await window.clipsta?.saveFFmpegClip(seconds);
			if (savedPath) {
				setState((s) => ({ ...s, status: "recording", savedPath }));
				return savedPath;
			} else {
				setState((s) => ({ ...s, status: "recording", error: "Not enough buffer yet" }));
				return null;
			}
		} catch (err: any) {
			setState((s) => ({ ...s, status: "recording", error: err.message ?? "Save failed" }));
			return null;
		}
	}, []);

	const saveFullRecording = useCallback(async (): Promise<string | null> => {
		const path = await saveClip(durationRef.current + 5);
		await stopRecording();
		return path;
	}, [saveClip, stopRecording]);

	const toggleRecording = useCallback(
		async (sourceId: string | null = null) => {
			if (state.status === "recording") await stopRecording();
			else await startRecording(sourceId);
		},
		[state.status, startRecording, stopRecording]
	);

	// Listen for capture status updates from main process (including errors)
	useEffect(() => {
		if (!window.clipsta) return;
		window.clipsta.onRecordingStatus((data: any) => {
			if (!data.isRecording && state.status === "recording") {
				if (timerRef.current) clearInterval(timerRef.current);
				timerRef.current = null;
				durationRef.current = 0;
				setState((s) => ({ ...s, status: "idle", duration: 0, error: data.error ?? null }));
				window.clipsta?.setRecordingState(false);
			}
		});
	}, [state.status]);

	// Hotkey listeners
	const toggleRef = useRef(toggleRecording);
	const saveRef = useRef(saveClip);
	toggleRef.current = toggleRecording;
	saveRef.current = saveClip;

	useEffect(() => {
		if (!window.clipsta) return;
		window.clipsta.onHotkeyRecord(() => toggleRef.current(sourceIdRef.current));
		window.clipsta.onHotkeyClip1Min(() => saveRef.current(60));
		window.clipsta.onHotkeyClip5Min(() => saveRef.current(300));
	}, []);

	return {
		state,
		startRecording,
		stopRecording,
		toggleRecording,
		saveClip,
		saveFullRecording,
		setSourceId: (id: string | null) => { sourceIdRef.current = id; },
	};
}
