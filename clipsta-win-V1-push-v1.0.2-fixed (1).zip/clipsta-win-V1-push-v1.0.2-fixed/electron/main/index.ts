import {
	app,
	BrowserWindow,
	ipcMain,
	desktopCapturer,
	globalShortcut,
	dialog,
	shell,
	Tray,
	Menu,
	nativeImage,
	powerSaveBlocker,
	session,
} from "electron";
import path from "path";
import fs from "fs";
import { execFile } from "child_process";
import Store from "electron-store";
import os from "os";
import { captureEngine, CaptureEngine } from "./captureEngine";

let _wasapiPath: string | null = null;
let _ffmpegPath: string | null = null;
function getWasapiExePath(): string | null {
	if (_wasapiPath !== null) return _wasapiPath || null;
	const candidates = [
		path.join(process.resourcesPath, "wasapi-capture.exe"),
		path.join(__dirname, "../../bin/wasapi-capture.exe"),
		path.join(__dirname, "../../../native/wasapi-capture.exe"),
	];
	for (const p of candidates) {
		if (fs.existsSync(p)) { _wasapiPath = p; return p; }
	}
	_wasapiPath = "";
	console.warn("[Clipsta] wasapi-capture.exe not found — build it from native/build.bat and place in bin/");
	return null;
}

function getFfmpegPath(): string {
	if (_ffmpegPath) return _ffmpegPath;
	const bundled = path.join(process.resourcesPath, "ffmpeg.exe");
	if (fs.existsSync(bundled)) { _ffmpegPath = bundled; return bundled; }
	const devPath = path.join(__dirname, "../../bin/ffmpeg.exe");
	if (fs.existsSync(devPath)) { _ffmpegPath = devPath; return devPath; }
	_ffmpegPath = "ffmpeg";
	return "ffmpeg";
}

function getEncoderArgs(encoder?: string, bitrateKbps?: number): { codec: string; extra: string[] } {
	// FIX: this previously only set a quality target (CRF/CQ) with no
	// bitrate ceiling at all, so the user's configured bitrate (the
	// ShadowPlay-equivalent 50 Mbps default) was never actually applied to
	// exported/trimmed/cropped clips — export quality was fully decoupled
	// from that setting. This is "capped CRF/CQ": quality-based encoding
	// stays in control for efficient bits on simple scenes, but -maxrate/
	// -bufsize (or NVENC's vbr-hq equivalent) caps the ceiling at the
	// configured bitrate, the same target+max-bitrate approach ShadowPlay's
	// own NVENC VBR mode uses — so fast-motion gameplay can't spike into an
	// uncapped, unpredictable bitrate, and exports don't regress in quality
	// relative to the original high-bitrate capture.
	const base = (() => {
		switch (encoder) {
			case "NVENC (NVIDIA)":
				return { codec: "h264_nvenc", extra: ["-preset", "p6", "-rc", "vbr", "-cq", "19", "-profile:v", "high", "-spatial-aq", "1", "-temporal-aq", "1", "-rc-lookahead", "20"] };
			case "AMF (AMD)":
				return { codec: "h264_amf", extra: ["-quality", "speed", "-rc", "cqp", "-qp_i", "20", "-qp_p", "22", "-profile:v", "high"] };
			case "QuickSync (Intel)":
				return { codec: "h264_qsv", extra: ["-preset", "medium", "-global_quality", "18", "-profile:v", "high"] };
			case "HEVC (H.265)":
				return { codec: "libx265", extra: ["-preset", "fast", "-crf", "20", "-profile:v", "main"] };
			case "x264 (Software)":
			default:
				return { codec: "libx264", extra: ["-preset", "fast", "-crf", "18", "-profile:v", "high", "-level", "4.2"] };
		}
	})();
	if (bitrateKbps && bitrateKbps > 0) {
		const maxrate = Math.round(bitrateKbps * 1.2);
		const bufsize = Math.round(bitrateKbps * 2);
		base.extra.push("-maxrate", `${maxrate}k`, "-bufsize", `${bufsize}k`);
	}
	return base;
}

const store = new Store({
	defaults: {
		outputFolder: "",
		hotkeyClip1Min: "Alt+F9",
		hotkeyClip5Min: "Alt+F10",
		hotkeyRecord: "F9",
		bufferDuration: 60,
		resolution: "1080p",
		fps: 60,
		aspectRatio: "16:9",
		encoder: "auto",
		bitrate: 80000,
		audioBitrate: 192,
		captureAudio: true,
		captureMic: false,
		audioSource: "desktop",
		audioInputDeviceId: "",
		gameDetect: true,
		autoUpload: false,
		minimizeToTray: true,
		overlayEnabled: true,
		cloudEnabled: false,
		cloudPairCode: "",
		uploadBandwidth: 0,
		deleteAfterUpload: false,
		desktopDeviceId: "",
		captureMode: "fullscreen",
		segmentDuration: 10,
		replayBufferEnabled: true,
		replayBufferDuration: 300,
	},
});

let mainWindow: BrowserWindow | null = null;
let tray: Tray | null = null;
let isRecording = false;
let powerBlockId: number | null = null;
let closeFromUi = false;
let pendingSourceId: string | null = null;

const gotLock = app.requestSingleInstanceLock();
if (!gotLock) app.quit();

app.on("second-instance", () => {
	if (mainWindow) {
		if (mainWindow.isMinimized()) mainWindow.restore();
		mainWindow.show();
		mainWindow.focus();
	}
});

app.whenReady().then(async () => {
	session.defaultSession.setPermissionRequestHandler((_wc, permission, callback) => {
		if (permission === "media" || permission === "display-capture") return callback(true);
		callback(false);
	});

	session.defaultSession.setDisplayMediaRequestHandler(async (_request, callback) => {
		const sources = await desktopCapturer.getSources({
			types: ["screen", "window"],
			thumbnailSize: { width: 320, height: 180 },
		});
		const source = pendingSourceId
			? sources.find((s) => s.id === pendingSourceId)
			: null;
		if (source) {
			callback({ video: source, audio: "loopback" });
		} else {
			callback({});
		}
	});

	ensureOutputFolder();
	ensureDesktopDeviceId();
	await createWindow();
	createTray();
	registerAllHotkeys();
});

app.on("window-all-closed", () => {});
app.on("will-quit", () => { globalShortcut.unregisterAll(); });
app.on("before-quit", (e) => {
	if (captureEngine.getState() !== "idle") {
		e.preventDefault();
		captureEngine.stop().finally(() => app.quit());
	}
});
app.on("activate", () => { if (!mainWindow) createWindow(); });

async function createWindow() {
	mainWindow = new BrowserWindow({
		width: 1400,
		height: 900,
		minWidth: 1100,
		minHeight: 720,
		frame: false,
		backgroundColor: "#0a0a0a",
		webPreferences: {
			preload: path.join(__dirname, "../preload/index.js"),
			contextIsolation: true,
			nodeIntegration: false,
			webSecurity: false,
		},
		show: false,
	});

	mainWindow.once("ready-to-show", () => {
		mainWindow!.show();
		mainWindow!.focus();
	});

	mainWindow.on("close", (e) => {
		if (closeFromUi) {
			closeFromUi = false;
			if (store.get("minimizeToTray")) {
				e.preventDefault();
				mainWindow!.hide();
				return;
			}
			return;
		}
		globalShortcut.unregisterAll();
		app.exit(0);
	});

	mainWindow.webContents.on("did-fail-load", () => {
		mainWindow?.loadFile(path.join(__dirname, "../../dist/index.html"));
	});

	const devUrl = process.env["VITE_DEV_SERVER_URL"];
	if (devUrl) {
		await mainWindow.loadURL(devUrl).catch(() =>
			mainWindow?.loadFile(path.join(__dirname, "../../dist/index.html"))
		);
	} else {
		await mainWindow.loadFile(path.join(__dirname, "../../dist/index.html"));
	}
}

function createTray() {
	try {
		const trayPath = path.join(__dirname, "../../dist/tray.png");
		const icon = fs.existsSync(trayPath)
			? nativeImage.createFromPath(trayPath)
			: nativeImage.createEmpty();
		tray = new Tray(icon);
		tray.setToolTip("Clipsta");
		refreshTrayMenu();
		tray.on("double-click", showWindow);
	} catch {}
}

function refreshTrayMenu() {
	const menu = Menu.buildFromTemplate([
		{ label: "Open Clipsta", click: showWindow },
		{ type: "separator" },
		{
			label: isRecording ? "Stop Recording" : "Start Recording",
			click: () => mainWindow?.webContents.send("hotkey:record"),
		},
		{ label: "Save 1-min Clip", click: () => mainWindow?.webContents.send("hotkey:clip1min") },
		{ label: "Save 5-min Clip", click: () => mainWindow?.webContents.send("hotkey:clip5min") },
		{ type: "separator" },
		{ label: "Open Clips Folder", click: () => shell.openPath(store.get("outputFolder") as string || app.getPath("videos")) },
		{ type: "separator" },
		{ label: "Quit Clipsta", click: () => { globalShortcut.unregisterAll(); app.exit(0); } },
	]);
	tray?.setContextMenu(menu);
}

function showWindow() {
	if (!mainWindow) createWindow();
	else { mainWindow.show(); mainWindow.focus(); }
}

function registerAllHotkeys() {
	globalShortcut.unregisterAll();
	tryRegister(store.get("hotkeyRecord") as string, () => mainWindow?.webContents.send("hotkey:record"));
	tryRegister(store.get("hotkeyClip1Min") as string, () => mainWindow?.webContents.send("hotkey:clip1min"));
	tryRegister(store.get("hotkeyClip5Min") as string, () => mainWindow?.webContents.send("hotkey:clip5min"));
}

function tryRegister(accelerator: string, fn: () => void) {
	try { if (accelerator) globalShortcut.register(accelerator, fn); } catch {}
}

function ensureOutputFolder() {
	let f = store.get("outputFolder") as string;
	if (!f) {
		f = path.join(app.getPath("videos"), "Clipsta");
		store.set("outputFolder", f);
	}
	if (!fs.existsSync(f)) fs.mkdirSync(f, { recursive: true });
}

function ensureDesktopDeviceId() {
	let id = store.get("desktopDeviceId") as string;
	if (!id) {
		id = `desktop_${crypto.randomUUID().replace(/-/g, "")}`;
		store.set("desktopDeviceId", id);
	}
}

// ── Recording engine (OBS-equivalent via ffmpeg) ──────────────────────
// IMPORTANT, for anyone reading this after the v1.0.4 "OBS engine" upload:
// there is no libobs/native C++ bridge in this app, and none has been added
// here. A genuine libobs integration means a native Node addon compiled
// against the real OBS SDK with MSVC, linked against obs.dll/obs-plugins —
// a real, large undertaking that can't be built or verified outside an
// actual Windows toolchain. What this file previously called "OBS engine"
// (electron/main/obs/ObsBackend.ts) was a stub: startReplayBuffer()/
// saveReplay() just returned hardcoded success objects and never touched
// ffmpeg, OBS, or disk. That's been removed.
//
// What's here instead is the same strategy libobs's replay-buffer module
// actually uses, implemented with ffmpeg (already bundled): continuous
// capture, GOP-aligned segments with a forced keyframe at every segment
// boundary, and instant stream-copy concat to save the last N seconds —
// see captureEngine.ts for the full rationale. Capture itself prefers
// `ddagrab` (DXGI Desktop Duplication — the same GPU-side API OBS's
// "Display Capture" and NVIDIA ShadowPlay use) and falls back to `gdigrab`
// automatically if unavailable.
captureEngine.setStateListener((state, detail) => {
	isRecording = state === "recording" || state === "starting";
	refreshTrayMenu();
	if (powerBlockId !== null) { powerSaveBlocker.stop(powerBlockId); powerBlockId = null; }
	if (isRecording) powerBlockId = powerSaveBlocker.start("prevent-display-sleep");
	mainWindow?.webContents.send("recording:status", {
		isRecording,
		startTime: isRecording ? Date.now() : null,
		error: state === "error" ? (detail ?? "Capture failed") : null,
	});
});

function getBufferDir() {
	return path.join(app.getPath("temp"), "clipsta-buffer");
}

ipcMain.handle("recording:startFFmpeg", async (_e, opts: Record<string, any>) => {
	const s = store.store;
	// Segment length = GOP/keyframe interval. The replay buffer must always
	// retain at least as much footage as the longest clip you can save (the
	// 5-min hotkey, or whatever Replay Buffer Duration is set to) — otherwise
	// "Save 5-min Clip" could silently return less than 5 minutes once older
	// segments get pruned.
	const segmentSeconds = Math.max(2, Math.min(60, opts.segmentDuration ?? s.segmentDuration ?? 4));
	// NOTE: Settings has two separate, independent controls for this — "Buffer
	// Duration" (Video section) and "Replay Buffer Duration" (gated behind the
	// "Replay Buffer" toggle in Capture Behavior). They aren't reconciled
	// anywhere else in the app; using only one would make the other a silent
	// no-op. Taking the max of whichever applies keeps both controls live.
	const replayWanted = s.replayBufferEnabled ? (s.replayBufferDuration ?? 300) : 0;
	const requestedBuffer = Math.max(s.bufferDuration ?? 60, replayWanted);
	const bufferDuration = Math.max(requestedBuffer, 320); // +headroom over the 5-min built-in hotkey

	const wantsMic = s.audioSource === "mic" || s.audioSource === "both";
	const wantsDesktop = s.audioSource === "desktop" || s.audioSource === "both";

	// Desktop/game audio: use WASAPI loopback exe (OBS method — works for
	// all applications, no Stereo Mix or virtual cable required).
	const wasapiExePath = wantsDesktop ? getWasapiExePath() : null;

	// Microphone: validate against real enumerated dshow devices
	let micAudioDeviceName: string | null = null;
	if (wantsMic) {
		const realDevices = await CaptureEngine.listAudioDevices(getFfmpegPath());
		if (s.audioInputDeviceId && realDevices.includes(s.audioInputDeviceId)) {
			micAudioDeviceName = s.audioInputDeviceId;
		} else if (realDevices.length > 0) {
			micAudioDeviceName = realDevices[0];
			console.warn(`[Clipsta] Mic "${s.audioInputDeviceId}" not found — falling back to "${micAudioDeviceName}"`);
		}
	}

	mainWindow?.webContents.send("audio:devices-resolved", {
		wasapiActive: !!wasapiExePath,
		micAudioDeviceName,
		allDevices: await CaptureEngine.listAudioDevices(getFfmpegPath()),
	});

	await captureEngine.start({
		ffmpegPath: getFfmpegPath(),
		bufferDir: getBufferDir(),
		fps: Math.max(1, opts.fps ?? s.fps ?? 60),
		resolution: opts.resolution ?? s.resolution ?? "1080p",
		encoder: opts.encoder ?? s.encoder ?? "auto",
		bitrate: opts.bitrate ?? s.bitrate ?? 50000,
		audioBitrate: s.audioBitrate ?? 192,
		bufferDuration,
		segmentSeconds,
		wasapiExePath,
		micAudioDeviceName,
	});

	return { startTime: Date.now(), segmentDir: getBufferDir() };
});

ipcMain.handle("recording:stopFFmpeg", async () => {
	await captureEngine.stop();
	return getBufferDir();
});

// NOTE: this channel name ("recording:saveFFmpegClip") previously didn't
// match what the main process had registered ("recording:saveOBSClip") —
// preload called one name, main listened on another, so every save request
// silently failed. Registering under the name preload actually invokes.
ipcMain.handle("recording:saveFFmpegClip", async (_e, seconds: number) => {
	const folder = (store.get("outputFolder") as string) || app.getPath("videos");
	if (!fs.existsSync(folder)) fs.mkdirSync(folder, { recursive: true });
	const now = new Date();
	const stamp = `${now.getFullYear()}${String(now.getMonth() + 1).padStart(2, "0")}${String(now.getDate()).padStart(2, "0")}_${String(now.getHours()).padStart(2, "0")}${String(now.getMinutes()).padStart(2, "0")}${String(now.getSeconds()).padStart(2, "0")}`;
	const label = seconds <= 60 ? "1min" : seconds <= 300 ? "5min" : `${Math.round(seconds)}s`;
	const outPath = path.join(folder, `Clipsta_${label}_${stamp}.mp4`);
	try {
		return await captureEngine.saveClip(seconds, outPath);
	} catch (err: any) {
		throw new Error(err?.message ?? "Save failed — buffer may not have enough footage yet");
	}
});

ipcMain.handle("recording:getStatus", () => {
	const diag = captureEngine.getDiagnostics();
	return { isRecording, ffmpeg: diag.state === "recording" || diag.state === "starting", segments: 0, ...diag };
});

ipcMain.handle("capture:listAudioDevices", async () => CaptureEngine.listAudioDevices(getFfmpegPath()));
ipcMain.handle("capture:detectDesktopLoopback", async () => CaptureEngine.detectDesktopLoopbackDevice(getFfmpegPath()));

// ── IPC: window controls ──────────────────────────────────────────────
ipcMain.on("win:minimize", () => mainWindow?.minimize());
ipcMain.on("win:maximize", () =>
	mainWindow?.isMaximized() ? mainWindow.unmaximize() : mainWindow?.maximize()
);
ipcMain.on("win:close", () => {
	closeFromUi = true;
	if (store.get("minimizeToTray")) mainWindow?.hide();
	else mainWindow?.close();
});

// ── IPC: screen sources ───────────────────────────────────────────────
ipcMain.handle("sources:get", async () => {
	const sources = await desktopCapturer.getSources({
		types: ["window", "screen"],
		thumbnailSize: { width: 320, height: 180 },
		fetchWindowIcons: true,
	});
	return sources.map((s) => ({
		id: s.id,
		name: s.name,
		thumbnail: s.thumbnail.toDataURL(),
		appIcon: s.appIcon?.toDataURL() ?? null,
	}));
});

ipcMain.handle("recording:setPendingSource", (_e, id: string | null) => { pendingSourceId = id; });

ipcMain.handle("recording:setState", (_e, recording: boolean) => {
	isRecording = recording;
	refreshTrayMenu();
	if (recording) {
		if (powerBlockId !== null) powerSaveBlocker.stop(powerBlockId);
		powerBlockId = powerSaveBlocker.start("prevent-display-sleep");
	} else if (powerBlockId !== null) {
		powerSaveBlocker.stop(powerBlockId);
		powerBlockId = null;
	}
});

// ── IPC: save exported blob ───────────────────────────────────────────
ipcMain.handle("dialog:saveExport", async (_e, defaultName: string) => {
	const folder = (store.get("outputFolder") as string) || app.getPath("videos");
	const r = await dialog.showSaveDialog(mainWindow!, {
		title: "Export clip",
		defaultPath: path.join(folder, defaultName),
		filters: [
			{ name: "MP4 Video", extensions: ["mp4"] },
			{ name: "WebM Video", extensions: ["webm"] },
			{ name: "MKV Video", extensions: ["mkv"] },
			{ name: "MOV Video", extensions: ["mov"] },
			{ name: "All Files", extensions: ["*"] },
		],
	});
	return r.canceled ? null : r.filePath;
});

ipcMain.handle("recording:save", async (_e, arrayBuffer: ArrayBuffer, fileName: string) => {
	const folder = (store.get("outputFolder") as string) || app.getPath("videos");
	if (!fs.existsSync(folder)) fs.mkdirSync(folder, { recursive: true });
	const filePath = path.join(folder, fileName);
	await fs.promises.writeFile(filePath, Buffer.from(arrayBuffer));
	return filePath;
});

// ── IPC: export via ffmpeg ────────────────────────────────────────────
ipcMain.handle("recording:export", async (_e, inputPath: string, outputPath: string, opts: Record<string, any>): Promise<string> => {
	const vfFilters: string[] = [];
	if (opts.cuts?.length) {
		const terms = opts.cuts.filter((c: any) => c.start < c.end).map((c: any) => `between(t,${c.start},${c.end})`);
		if (terms.length) vfFilters.push(`select='not(${terms.join("+")})',setpts=N/FRAME_RATE/TB`);
	}
	if (opts.aspectRatio === "9:16") vfFilters.push("crop=min(iw\\,ih*9/16):ih");
	else if (opts.aspectRatio === "4:3") vfFilters.push("crop=min(iw\\,ih*4/3):ih");
	const pValues: Record<string, number> = { "480p": 480, "720p": 720, "1080p": 1080, "1440p": 1440, "4k": 2160 };
	const p = opts.resolution ? pValues[opts.resolution] : null;
	if (p) vfFilters.push(opts.aspectRatio !== "9:16" ? `scale=-2:${p}` : `scale=${p}:-2`);

	const args: string[] = [];
	let isMultiClip = false;

	if (opts.timeline?.length > 1) {
		isMultiClip = true;
		const parts: string[] = [];
		const labels: string[] = [];
		for (let i = 0; i < opts.timeline.length; i++) {
			const clip = opts.timeline[i];
			args.push("-hwaccel", "auto", "-i", clip.path);
			const vl = `v${i}`, al = `a${i}`;
			if (clip.trimIn > 0 || clip.trimOut > 0) {
				const t = [clip.trimIn > 0 ? `start=${clip.trimIn}` : "", clip.trimOut > 0 ? `end=${clip.trimOut}` : ""].filter(Boolean).join(":");
				parts.push(`[${i}:v]trim=${t},setpts=PTS-STARTPTS[${vl}]`, `[${i}:a]atrim=${t},asetpts=PTS-STARTPTS[${al}]`);
			} else parts.push(`[${i}:v]setpts=PTS-STARTPTS[${vl}]`, `[${i}:a]asetpts=PTS-STARTPTS[${al}]`);
			labels.push(`[${vl}][${al}]`);
		}
		const concat = `${labels.join("")}concat=n=${opts.timeline.length}:v=1:a=1:unsafe=1[vm][am]`;
		parts.push(concat);
		if (vfFilters.length) { parts.push(`[vm]${vfFilters.join(",")}[vo]`); args.push("-filter_complex", parts.join(";"), "-map", "[vo]", "-map", "[am]"); }
		else args.push("-filter_complex", parts.join(";"), "-map", "[vm]", "-map", "[am]");
	} else {
		args.push("-hwaccel", "auto", "-i", inputPath);
		if (opts.trimStart != null) args.push("-ss", String(opts.trimStart));
		if (opts.trimEnd != null) args.push("-to", String(opts.trimEnd));
	}

	if (!isMultiClip && vfFilters.length) args.push("-vf", vfFilters.join(","));
	if (opts.cuts?.length) {
		const aTerms = opts.cuts.filter((c: any) => c.start < c.end).map((c: any) => `between(t,${c.start},${c.end})`);
		if (aTerms.length) args.push("-af", `aselect='not(${aTerms.join("+")})',asetpts=N/SR/TB`);
	}
	const enc = getEncoderArgs(opts.encoder, opts.bitrate ?? (store.get("bitrate") as number) ?? 50000);
	args.push("-c:v", enc.codec, ...enc.extra);
	if (opts.fps) args.push("-r", String(opts.fps));
	args.push("-c:a", "aac", "-b:a", "192k", "-movflags", "+faststart", "-y", outputPath);

	return new Promise((resolve, reject) => {
		execFile(getFfmpegPath(), args, { timeout: 300000, maxBuffer: 100 * 1024 * 1024 }, (err, _so, se) => {
			if (err) reject(`FFmpeg error: ${(se || err.message).split("\n").slice(-3).join(" ").trim()}`);
			else resolve(outputPath);
		});
	});
});

// ── IPC: settings ─────────────────────────────────────────────────────
ipcMain.handle("settings:getAll", () => store.store);
ipcMain.handle("settings:set", (_e, key: string, value: unknown) => {
	(store as any).set(key, value);
	if (["hotkeyRecord", "hotkeyClip1Min", "hotkeyClip5Min"].includes(key)) registerAllHotkeys();
	if (key === "outputFolder") ensureOutputFolder();
	return true;
});
ipcMain.handle("settings:setAll", (_e, settings: Record<string, any>) => {
	Object.entries(settings).forEach(([k, v]) => (store as any).set(k, v));
	registerAllHotkeys();
	ensureOutputFolder();
	return true;
});

// ── IPC: dialogs ──────────────────────────────────────────────────────
ipcMain.handle("dialog:folder", async () => {
	const r = await dialog.showOpenDialog(mainWindow!, { properties: ["openDirectory", "createDirectory"], title: "Choose clips output folder" });
	return r.canceled ? null : r.filePaths[0];
});
ipcMain.handle("dialog:importFolder", async () => {
	const r = await dialog.showOpenDialog(mainWindow!, { properties: ["openDirectory"], title: "Select a folder of video clips to import" });
	return r.canceled ? null : r.filePaths[0];
});
ipcMain.handle("dialog:file", async () => {
	const r = await dialog.showOpenDialog(mainWindow!, {
		properties: ["openFile"], title: "Open video file",
		filters: [{ name: "Video Files", extensions: ["webm", "mp4", "mkv", "mov", "avi"] }, { name: "All Files", extensions: ["*"] }],
	});
	return r.canceled ? null : r.filePaths[0];
});

// ── IPC: shell ────────────────────────────────────────────────────────
ipcMain.handle("shell:openFolder", (_e, p: string) => shell.openPath(p));
ipcMain.handle("shell:openFile", (_e, p: string) => shell.openPath(p));
ipcMain.handle("shell:showItem", (_e, p: string) => shell.showItemInFolder(p));

// ── IPC: clip library ─────────────────────────────────────────────────
ipcMain.handle("clips:list", async () => {
	const folder = store.get("outputFolder") as string;
	if (!folder || !fs.existsSync(folder)) return [];
	const entries = await fs.promises.readdir(folder, { withFileTypes: true });
	const results: { name: string; path: string; size: number; createdAt: string }[] = [];
	for (const entry of entries) {
		if (!/\.(webm|mp4|mkv|mov)$/i.test(entry.name)) continue;
		if (entry.name.startsWith("_")) continue;
		try {
			const stat = await fs.promises.stat(path.join(folder, entry.name));
			results.push({ name: entry.name, path: path.join(folder, entry.name), size: stat.size, createdAt: stat.birthtime.toISOString() });
		} catch {}
	}
	return results.sort((a, b) => +new Date(b.createdAt) - +new Date(a.createdAt));
});
ipcMain.handle("clips:delete", async (_e, p: string) => {
	if (!fs.existsSync(p)) return true;
	for (let i = 0; i < 5; i++) {
		try { await fs.promises.unlink(p); return true; }
		catch (err: any) {
			if ((err.code === "EBUSY" || err.code === "EPERM") && i < 4) {
				await new Promise((r) => setTimeout(r, 500));
			} else throw err;
		}
	}
	return true;
});
ipcMain.handle("clips:rename", async (_e, oldPath: string, newName: string) => {
	const newPath = path.join(path.dirname(oldPath), newName);
	await fs.promises.rename(oldPath, newPath);
	return newPath;
});
ipcMain.handle("clips:import", async (_e, sourcePath: string) => {
	const folder = store.get("outputFolder") as string;
	if (!fs.existsSync(folder)) fs.mkdirSync(folder, { recursive: true });
	const name = path.basename(sourcePath);
	const dest = path.join(folder, name);
	if (fs.existsSync(dest)) {
		const ext = path.extname(name), base = path.basename(name, ext);
		let i = 1; while (fs.existsSync(path.join(folder, `${base} (${i})${ext}`))) i++;
		const finalDest = path.join(folder, `${base} (${i})${ext}`);
		await fs.promises.copyFile(sourcePath, finalDest);
		return finalDest;
	}
	await fs.promises.copyFile(sourcePath, dest);
	return dest;
});
ipcMain.handle("clips:importFolder", async (_e, sourceFolder: string) => {
	const folder = store.get("outputFolder") as string;
	if (!fs.existsSync(folder)) fs.mkdirSync(folder, { recursive: true });
	const imported: string[] = [];
	const files = (await fs.promises.readdir(sourceFolder)).filter(f => /\.(webm|mp4|mkv|mov)$/i.test(f));
	for (const f of files) {
		const src = path.join(sourceFolder, f), dest = path.join(folder, f);
		const ext = path.extname(f), base = path.basename(f, ext);
		if (fs.existsSync(dest)) {
			let i = 1; while (fs.existsSync(path.join(folder, `${base} (${i})${ext}`))) i++;
			const fp = path.join(folder, `${base} (${i})${ext}`);
			await fs.promises.copyFile(src, fp); imported.push(fp);
		} else { await fs.promises.copyFile(src, dest); imported.push(dest); }
	}
	return imported;
});

// ── IPC: system info ──────────────────────────────────────────────────
ipcMain.handle("system:info", () => ({
	platform: process.platform, arch: process.arch, totalMem: os.totalmem(), freeMem: os.freemem(), cpus: os.cpus().length,
}));

// ── IPC: file ops ─────────────────────────────────────────────────────
ipcMain.handle("file:read", async (_e, filePath: string) => (await fs.promises.readFile(filePath)).buffer);
ipcMain.handle("file:stat", async (_e, filePath: string) => {
	const s = await fs.promises.stat(filePath);
	return { size: s.size, modifiedAt: s.mtime.toISOString() };
});
ipcMain.handle("file:ensureDir", async (_e, dirPath: string) => { await fs.promises.mkdir(dirPath, { recursive: true }); return true; });

// ── IPC: cloud upload ─────────────────────────────────────────────────
const API_BASE = "https://clipsta-api.godson594.workers.dev";
const DESKTOP_TEST_KEY = process.env.CLIPSTA_API_KEY || "32b28eac803a1b24c19e20665919eaeb7f1493d2b5e3f68be7944db6d9f01b96";

ipcMain.handle("cloud:getConfig", () => ({ apiBase: API_BASE, apiKey: DESKTOP_TEST_KEY }));

ipcMain.handle("upload:clip", async (_e, opts: Record<string, any>) => {
	const controller = new AbortController();
	const uploadTimer = setTimeout(() => controller.abort(), 120000);
	let cleanupPath: string | null = null;
	try {
		let uploadPath = opts.filePath, uploadName = opts.fileName;
		if (opts.trimStart != null || opts.trimEnd != null || (opts.cuts?.length > 0)) {
			const ext = path.extname(opts.fileName) || ".mp4";
			const base = path.basename(opts.fileName, ext);
			cleanupPath = path.join(app.getPath("temp"), `clipsta_upload_${base}_${Date.now()}${ext}`);
			const vf: string[] = [];
			if (opts.cuts?.length) {
				const terms = opts.cuts.filter((c: any) => c.start < c.end).map((c: any) => `between(t,${c.start},${c.end})`);
				if (terms.length) vf.push(`select='not(${terms.join("+")})',setpts=N/FRAME_RATE/TB`);
			}
			const ea = ["-hwaccel", "auto", "-i", opts.filePath];
			if (opts.trimStart != null) ea.push("-ss", String(opts.trimStart));
			if (opts.trimEnd != null) ea.push("-to", String(opts.trimEnd));
			if (vf.length) ea.push("-vf", vf.join(","));
			if (opts.cuts?.length) {
				const aTerms = opts.cuts.filter((c: any) => c.start < c.end).map((c: any) => `between(t,${c.start},${c.end})`);
				if (aTerms.length) ea.push("-af", `aselect='not(${aTerms.join("+")})',asetpts=N/SR/TB`);
			}
			const enc = getEncoderArgs(opts.encoder, opts.bitrate ?? (store.get("bitrate") as number) ?? 50000);
			ea.push("-c:v", enc.codec, ...enc.extra, "-c:a", "aac", "-b:a", "192k", "-movflags", "+faststart", "-y", cleanupPath);
			await new Promise((resolve, reject) => execFile(getFfmpegPath(), ea, { timeout: 300000, maxBuffer: 100*1024*1024 }, (err, _so, se) => {
				if (err) reject(`FFmpeg export error: ${(se||err.message).split("\n").slice(-3).join(" ").trim()}`); else resolve(null);
			}));
			uploadPath = cleanupPath; uploadName = `${base}.mp4`;
		}
		let actualBytes = opts.bytes;
		try { actualBytes = fs.statSync(uploadPath).size; } catch {}
		const clipRes = await fetch(`${API_BASE}/clip-uploads`, {
			method: "POST", headers: { "Content-Type": "application/json", "X-Clipsta-Test-Key": DESKTOP_TEST_KEY },
			body: JSON.stringify({ desktopDeviceId: opts.desktopDeviceId, fileName: uploadName, durationSeconds: opts.durationSeconds, bytes: actualBytes, capturedAt: opts.capturedAt }),
			signal: controller.signal,
		});
		if (!clipRes.ok) throw new Error(`clip-uploads failed: HTTP ${clipRes.status} ${await clipRes.text().catch(()=>"")}`);
		const clipData = await clipRes.json();
		const fileBuf = await fs.promises.readFile(uploadPath);
		const mime = uploadName.endsWith(".webm") ? "video/webm" : uploadName.endsWith(".mkv") ? "video/x-matroska" : uploadName.endsWith(".mov") ? "video/quicktime" : "video/mp4";
		const boundary = `----ClipstaBoundary${Math.random().toString(36).slice(2)}`;
		const head = Buffer.from(`--${boundary}\r\nContent-Disposition: form-data; name="file"; filename="${uploadName}"\r\nContent-Type: ${mime}\r\n\r\n`, "utf-8");
		const tail = Buffer.from(`\r\n--${boundary}--\r\n`, "utf-8");
		const uploadRes = await fetch((clipData as any).uploadUrl, {
			method: "POST", headers: { "Content-Type": `multipart/form-data; boundary=${boundary}` }, body: Buffer.concat([head, fileBuf, tail]),
			signal: controller.signal,
		});
		if (!uploadRes.ok) throw new Error(`file upload failed: HTTP ${uploadRes.status} ${await uploadRes.text().catch(()=>"")}`);
		return clipData;
	} finally {
		clearTimeout(uploadTimer);
		if (cleanupPath) try { fs.unlinkSync(cleanupPath); } catch {}
	}
});

ipcMain.handle("upload:status", async (_e, body: Record<string, any>) => {
	const res = await fetch(`${API_BASE}/desktop-upload-status`, {
		method: "POST", headers: { "Content-Type": "application/json", "X-Clipsta-Test-Key": DESKTOP_TEST_KEY },
		body: JSON.stringify(body),
	});
	if (!res.ok) console.warn("upload-status failed:", res.status);
});
