// ─────────────────────────────────────────────────────────────────────────────
// CaptureEngine — OBS-style continuous segmented capture + instant replay save
//
// WHY THIS EXISTS
// The old pipeline used the browser's MediaRecorder API on a getDisplayMedia
// stream, sliced into 100ms chunks held in renderer memory. That approach has
// a structural flaw: MediaRecorder/Chromium decides keyframe placement on its
// own (no exposed GOP control), so slicing the in-memory chunk buffer to make
// a "last N seconds" clip very often cuts the window *before* the nearest
// keyframe. The resulting webm then has delta frames with no reference frame
// to decode against — which is exactly the choppy/corrupted playback bug.
// It also ties capture to the renderer's video element, so minimizing or
// backgrounding the window can starve/crash the encode pipeline.
//
// OBS solves this in libobs's replay-buffer module by encoding continuously
// with a fixed keyframe interval and only ever flushing whole, independently
// decodable GOPs when a replay is saved — never a partial GOP. We port that
// exact strategy using ffmpeg (already bundled in Clipsta) instead of libobs:
//
//   1. A single long-running ffmpeg process captures the desktop and loopback
//      audio (dshow), continuously writing fixed-length segment files via the
//      `segment` muxer, with a forced keyframe at the start of every segment
//      (-g / -force_key_frames). Every segment is therefore a fully
//      self-contained, cleanly decodable unit — same guarantee OBS gives its
//      GOPs.
//
//      Capture method: OBS's default Windows "Display Capture" source uses
//      the DXGI Desktop Duplication API — a GPU-side capture path, the same
//      one NVIDIA ShadowPlay uses. FFmpeg exposes this as the `ddagrab`
//      filter. We use it as the primary capture path and only fall back to
//      `gdigrab` (CPU/GDI bitblt) when ddagrab isn't available in the bundled
//      ffmpeg build. This matters: gdigrab is a CPU-bound blit loop that
//      reliably struggles to sustain 60fps, especially at 1080p+ — no amount
//      of downstream CFR correction fixes a source that can't deliver enough
//      real frames per second in the first place. ddagrab captures GPU
//      textures directly and is the actual fix for "fps not smooth."
//   2. A rolling buffer directory holds the last `bufferDuration` seconds of
//      segments; older segments are pruned on a timer.
//   3. "Save last N seconds" = pick the trailing segments covering N seconds
//      and stream-copy-concat them (-c copy) into the final MP4. No
//      re-encode, instant, and frame-accurate because every cut point is a
//      keyframe boundary by construction. This is the direct equivalent of
//      OBS's "Save Replay".
//   4. The watchdog restarts ffmpeg on unexpected exit with capped retries
//      and exponential backoff, instead of the old unbounded fallback loop
//      that could spin forever.
// ─────────────────────────────────────────────────────────────────────────────

import { spawn, execFile, ChildProcess } from "child_process";
import fs from "fs";
import path from "path";
import os from "os";

export type CaptureState = "idle" | "starting" | "recording" | "stopping" | "error";
export type CaptureMethod = "ddagrab" | "gdigrab";

// ── WasapiCapture ─────────────────────────────────────────────────────────────
// Manages the lifecycle of wasapi-capture.exe — the native exe that uses
// IAudioClient+AUDCLNT_STREAMFLAGS_LOOPBACK (OBS's exact technique) to
// capture desktop/game audio from ALL applications with no dependency on
// Stereo Mix or virtual audio cables.
//
// The exe creates a Windows named pipe as server; ffmpeg connects as client
// and reads raw s16le 48kHz stereo PCM from it. This keeps the audio path
// entirely outside Node's main thread.
export class WasapiCapture {
	private proc: ChildProcess | null = null;
	private pipeName: string = "";

	// Returns the Windows named pipe path to pass to ffmpeg as -i
	getPipeName(): string { return this.pipeName; }

	async start(exePath: string): Promise<string> {
		// Each recording session gets a unique pipe name so there's no
		// collision if a previous session didn't clean up cleanly.
		this.pipeName = `\\\\.\\pipe\\clipsta-audio-${process.pid}-${Date.now()}`;

		return new Promise((resolve, reject) => {
			const proc = spawn(exePath, [this.pipeName], {
				windowsHide: true,
				stdio: ["ignore", "ignore", "pipe"],
			});
			this.proc = proc;
			proc.stderr?.on("error", () => {});

			let ready = false;
			const timeout = setTimeout(() => {
				if (!ready) {
					proc.kill();
					reject(new Error("wasapi-capture.exe did not start within 8s"));
				}
			}, 8000);

			proc.stderr?.on("data", (chunk: Buffer) => {
				const text = chunk.toString();
				// The exe writes "ffmpeg connected" once the pipe handshake
				// completes — that's when we know it's safe to pass the pipe
				// name to ffmpeg.
				if (!ready && /waiting for ffmpeg|Pipe created/i.test(text)) {
					ready = true;
					clearTimeout(timeout);
					resolve(this.pipeName);
				}
				if (/error|failed/i.test(text)) {
					console.error("[wasapi-capture]", text.trim());
				}
			});

			proc.on("exit", (code) => {
				this.proc = null;
				if (!ready) {
					clearTimeout(timeout);
					reject(new Error(`wasapi-capture.exe exited early (code ${code})`));
				}
			});
			proc.on("error", (err) => {
				clearTimeout(timeout);
				this.proc = null;
				reject(new Error(`Failed to spawn wasapi-capture.exe: ${err.message}`));
			});
		});
	}

	stop() {
		if (this.proc) {
			try { this.proc.kill(); } catch { /* already gone */ }
			this.proc = null;
		}
	}
}

export interface CaptureOptions {
	ffmpegPath: string;
	bufferDir: string;
	fps: number;
	resolution: string; // "480p" | "720p" | "1080p" | "1440p" | "4k"
	encoder?: string; // "auto" | "NVENC (NVIDIA)" | "AMF (AMD)" | "QuickSync (Intel)" | "HEVC (H.265)" | "x264 (Software)"
	bitrate: number; // kbps
	audioBitrate: number; // kbps
	bufferDuration: number; // seconds of rolling buffer to retain
	wasapiExePath?: string | null; // path to wasapi-capture.exe; null = use lavfi silence
	micAudioDeviceName?: string | null; // dshow device name for microphone (optional)
	monitorIndex?: number; // which display to grab (output_idx for ddagrab, offset for gdigrab)
	segmentSeconds?: number; // GOP/segment length; default 4s — matches typical OBS keyframe interval
	captureMethod?: CaptureMethod; // force a method; omit to auto-detect (ddagrab preferred)
}

interface SegmentInfo {
	file: string;
	mtimeMs: number;
}

const DEFAULT_SEGMENT_SECONDS = 4;
const MAX_RESTARTS = 4;
const RESTART_WINDOW_MS = 60_000;

function resolutionToHeight(res: string): number | null {
	const map: Record<string, number> = { "480p": 480, "720p": 720, "1080p": 1080, "1440p": 1440, "4k": 2160 };
	return map[res] ?? null;
}

// ── Hardware capabilities are probed once per app session and cached ─────────
let cachedCaptureMethod: CaptureMethod | null = null;
let cachedBestEncoder: string | null = null;

async function detectCaptureMethod(ffmpegPath: string): Promise<CaptureMethod> {
	if (cachedCaptureMethod) return cachedCaptureMethod;
	const supported = await new Promise<boolean>((resolve) => {
		execFile(ffmpegPath, ["-hide_banner", "-filters"], { timeout: 8000 }, (_err, stdout) => {
			resolve(/\bddagrab\b/.test(stdout || ""));
		});
	});
	cachedCaptureMethod = supported ? "ddagrab" : "gdigrab";
	return cachedCaptureMethod;
}

// Mirrors OBS's own "Simple Output" hardware-encoder auto-detection: prefer
// the GPU vendor's encoder (NVENC, then QuickSync, then AMF) and only fall
// back to software x264 if no hardware path is available. This is also what
// gives ShadowPlay-comparable smoothness/perf — software encode under load
// is a common secondary cause of dropped/uneven frames even once capture
// itself is fast.
async function detectBestEncoder(ffmpegPath: string): Promise<string> {
	if (cachedBestEncoder) return cachedBestEncoder;
	const available = await new Promise<string>((resolve) => {
		execFile(ffmpegPath, ["-hide_banner", "-encoders"], { timeout: 8000 }, (_err, stdout) => {
			resolve(stdout || "");
		});
	});
	if (/\bh264_nvenc\b/.test(available)) cachedBestEncoder = "NVENC (NVIDIA)";
	else if (/\bh264_qsv\b/.test(available)) cachedBestEncoder = "QuickSync (Intel)";
	else if (/\bh264_amf\b/.test(available)) cachedBestEncoder = "AMF (AMD)";
	else cachedBestEncoder = "x264 (Software)";
	return cachedBestEncoder;
}

function encoderToFfmpegArgs(encoder?: string): { codec: string; extra: string[] } {
	switch (encoder) {
		case "NVENC (NVIDIA)":
			// p4/vbr/cq19 mirrors NVIDIA ShadowPlay's "High Quality" tuning more
			// closely than a faster preset + higher cq would; the GPU has plenty
			// of headroom for this on anything ShadowPlay itself targets.
			return { codec: "h264_nvenc", extra: ["-preset", "p4", "-rc", "vbr", "-cq", "19", "-bf", "3"] };
		case "AMF (AMD)":
			return { codec: "h264_amf", extra: ["-quality", "balanced", "-rc", "cqp", "-qp_i", "20", "-qp_p", "20"] };
		case "QuickSync (Intel)":
			return { codec: "h264_qsv", extra: ["-preset", "medium", "-global_quality", "20"] };
		case "HEVC (H.265)":
			return { codec: "libx265", extra: ["-preset", "veryfast", "-crf", "21"] };
		case "x264 (Software)":
		default:
			return { codec: "libx264", extra: ["-preset", "veryfast", "-crf", "19"] };
	}
}

export class CaptureEngine {
	private proc: ChildProcess | null = null;
	private wasapiCapture = new WasapiCapture();
	private state: CaptureState = "idle";
	private opts: CaptureOptions | null = null;
	private pruneTimer: NodeJS.Timeout | null = null;
	private restartTimestamps: number[] = [];
	private stderrTail: string[] = [];
	private onStateChange: ((s: CaptureState, detail?: string) => void) | null = null;
	private manualStop = false;

	setStateListener(cb: (s: CaptureState, detail?: string) => void) {
		this.onStateChange = cb;
	}

	getState(): CaptureState {
		return this.state;
	}

	getDiagnostics() {
		return {
			state: this.state,
			stderrTail: this.stderrTail.slice(-20),
			captureMethod: this.opts?.captureMethod,
			encoder: this.opts?.encoder,
		};
	}

	private setState(s: CaptureState, detail?: string) {
		this.state = s;
		this.onStateChange?.(s, detail);
	}

	// ── List available dshow audio devices (best-effort parse) ────────────────
	// ── List dshow audio devices with correct regex for real Windows output ──
	// FIXED: the previous regex was `/"([^"]+)"\s*\(audio\)/g` which matches
	// ZERO devices against real Windows ffmpeg output. Actual format:
	//   [dshow @ 0x...] DirectShow audio devices
	//   [dshow @ 0x...]  "Microphone (Realtek High Definition Audio)"
	//   [dshow @ 0x...]     Alternative name "@device_cm_{...}"
	// There is no "(audio)" suffix. Devices are quoted names on lines after
	// the "DirectShow audio devices" header, before the next section header.
	// We exclude "Alternative name" lines (start with @) and video devices.
	static async listAudioDevices(ffmpegPath: string): Promise<string[]> {
		return new Promise((resolve) => {
			execFile(
				ffmpegPath,
				["-hide_banner", "-list_devices", "true", "-f", "dshow", "-i", "dummy"],
				{ timeout: 10000 },
				(_err, _stdout, stderr) => {
					const output = stderr || "";
					const names: string[] = [];
					let inAudioSection = false;
					for (const line of output.split("\n")) {
						if (/DirectShow audio devices/i.test(line)) {
							inAudioSection = true;
							continue;
						}
						// A new section header ends the audio section
						if (/DirectShow video devices/i.test(line)) {
							inAudioSection = false;
							continue;
						}
						if (inAudioSection) {
							// Match quoted device names, skip Alternative name lines (@device_...)
							const m = line.match(/"([^"@][^"]*)"/);
							if (m && !m[1].startsWith("@")) names.push(m[1]);
						}
					}
					resolve(names);
				}
			);
		});
	}

	// ── Detect desktop/game loopback device ───────────────────────────────
	// On Windows, ffmpeg's dshow has no driverless WASAPI loopback.
	// Desktop audio requires: Stereo Mix (must be enabled in Sound settings),
	// or a virtual audio cable (VB-Cable, VoiceMeeter, etc.).
	// This scans the now-correctly-parsed device list for known loopback names.
	static async detectDesktopLoopbackDevice(ffmpegPath: string): Promise<string | null> {
		const devices = await CaptureEngine.listAudioDevices(ffmpegPath);
		const loopbackPatterns = [
			/stereo mix/i,
			/what u hear/i,
			/wave out mix/i,
			/loopback/i,
			/cable output/i,
			/virtual.*cable/i,
			/voicemeeter/i,
			/vb-audio/i,
			/blackhole/i,
		];
		for (const pattern of loopbackPatterns) {
			const match = devices.find((d) => pattern.test(d));
			if (match) return match;
		}
		return null;
	}

	// ── Start continuous capture ────────────────────────────────────────────
	async start(opts: CaptureOptions): Promise<void> {
		if (this.state === "recording" || this.state === "starting") return;
		this.manualStop = false;
		this.restartTimestamps = [];

		const resolvedMethod = opts.captureMethod ?? (await detectCaptureMethod(opts.ffmpegPath));
		const resolvedEncoder =
			!opts.encoder || opts.encoder === "auto" ? await detectBestEncoder(opts.ffmpegPath) : opts.encoder;

		// Start WASAPI loopback capture before ffmpeg so the named pipe
		// server is ready and waiting when ffmpeg tries to open it.
		let wasapiPipeName: string | null = null;
		if (opts.wasapiExePath) {
			try {
				wasapiPipeName = await this.wasapiCapture.start(opts.wasapiExePath);
			} catch (err: any) {
				console.warn("[CaptureEngine] WASAPI capture unavailable:", err.message,
					"— desktop audio will be silent this recording.");
			}
		}

		this.opts = {
			...opts,
			captureMethod: resolvedMethod,
			encoder: resolvedEncoder,
			// Store the resolved pipe name so spawnFfmpeg can read it
			_wasapiPipeName: wasapiPipeName,
		} as any;

		await fs.promises.mkdir(opts.bufferDir, { recursive: true });
		this.clearBufferDir(opts.bufferDir);
		this.setState("starting", `Using ${resolvedMethod} + ${resolvedEncoder}${wasapiPipeName ? " + WASAPI audio" : ""}`);
		this.spawnFfmpeg();
		this.pruneTimer = setInterval(() => this.pruneOldSegments(), 15_000);
	}

	private clearBufferDir(dir: string) {
		try {
			for (const f of fs.readdirSync(dir)) {
				if (f.startsWith("seg_")) fs.unlinkSync(path.join(dir, f));
			}
		} catch {
			/* ignore */
		}
	}

	private spawnFfmpeg() {
		if (!this.opts) return;
		const o = this.opts;
		const segSec = o.segmentSeconds ?? DEFAULT_SEGMENT_SECONDS;
		const enc = encoderToFfmpegArgs(o.encoder);
		const height = resolutionToHeight(o.resolution);
		const method = o.captureMethod ?? "gdigrab";
		const gop = segSec * o.fps;

		// ── Build args in the EXACT ORDER ffmpeg requires ──────────────────
		// ffmpeg is order-sensitive: global options → inputs (each with their
		// own input-specific options) → filter_complex (if any) → per-stream
		// maps and encode options → output. Getting this order wrong is the
		// #1 cause of silent audio drops and filter graph failures.
		const args: string[] = [
			"-y",
			"-hide_banner",
			"-loglevel", "warning",
			// Reduce input probing time — ffmpeg's default probesize/analyzeduration
			// can add 1-2s of startup latency while it auto-detects streams.
			// These values match OBS's own capture source defaults.
			"-probesize", "32",
			"-analyzeduration", "0",
			"-fflags", "+nobuffer+flush_packets",
		];

		// ── INPUT 0: Video ────────────────────────────────────────────────
		if (method === "ddagrab") {
			// DXGI Desktop Duplication — GPU-side capture, same API OBS's
			// "Display Capture" and NVIDIA ShadowPlay use. Captures the
			// compositor output directly, never dropping frames under GPU load
			// the way gdigrab (CPU bitblt) does. This is the real fix for
			// sustained 60fps, not just CFR timestamp correction downstream.
			const outputIdx = o.monitorIndex ?? 0;
			args.push(
				"-f", "lavfi",
				"-i", `ddagrab=output_idx=${outputIdx}:framerate=${o.fps}:draw_mouse=1`
			);
		} else {
			// gdigrab fallback — CPU/GDI bitblt. Works everywhere but can
			// genuinely fail to deliver 60fps at 1080p+ under load.
			// -framerate here is both the capture rate AND the declared input
			// fps — without it ffmpeg defaults to 30fps regardless of what
			// you put in -r later.
			args.push(
				"-f", "gdigrab",
				"-framerate", String(o.fps),
				"-draw_mouse", "1",
				"-thread_queue_size", "4096",
				"-i", "desktop"
			);
		}

		// ── INPUTS 1+: Audio ──────────────────────────────────────────────
		// Desktop/game audio comes from the WASAPI named pipe (wasapi-capture.exe).
		// Microphone comes from dshow directly (no loopback needed for mic).
		// thread_queue_size must be set *before* each -i.
		const audioInputIndices: number[] = [];
		let nextIdx = 1;

		// Retrieve the WASAPI pipe name stored by start()
		const wasapiPipe: string | null = (this.opts as any)._wasapiPipeName ?? null;

		if (wasapiPipe) {
			// ffmpeg reads raw s16le PCM from the named pipe that
			// wasapi-capture.exe (the server) is writing into.
			args.push(
				"-f", "s16le",
				"-ar", "48000",
				"-ac", "2",
				"-thread_queue_size", "4096",
				"-i", wasapiPipe
			);
			audioInputIndices.push(nextIdx++);
		}

		if (o.micAudioDeviceName) {
			args.push(
				"-f", "dshow",
				"-thread_queue_size", "4096",
				"-audio_buffer_size", "50",
				"-i", `audio=${o.micAudioDeviceName}`
			);
			audioInputIndices.push(nextIdx++);
		}

		if (audioInputIndices.length === 0) {
			// No audio at all — silent fallback track
			args.push("-f", "lavfi", "-i", "anullsrc=channel_layout=stereo:sample_rate=48000");
			audioInputIndices.push(nextIdx++);
		}

		// ── FILTER COMPLEX (must come before -map) ────────────────────────
		// CRITICAL ORDER: -filter_complex must be declared before any -map
		// that references its output labels. Placing it after -map causes
		// ffmpeg to silently drop the filter graph — this was why audio was
		// never making it through even when inputs were correctly configured.
		const filters: string[] = [];

		// ddagrab → NVENC zero-copy: D3D11 hardware frames go straight into
		// NVENC without a CPU round-trip. For all other encoder paths,
		// bring frames down to CPU-side bgra first.
		const isNvencZeroCopy = method === "ddagrab" && enc.codec === "h264_nvenc";
		if (method === "ddagrab" && !isNvencZeroCopy) {
			filters.push(`[0:v]hwdownload,format=bgra${height ? `,scale=-2:${height}` : ""}[vout]`);
		} else if (height) {
			filters.push(`[0:v]scale=-2:${height}[vout]`);
		}

		// Audio mix: amix when both desktop + mic, direct copy otherwise.
		// normalize=0 preserves per-source volume levels instead of halving
		// them when two inputs are summed (ffmpeg amix default).
		let audioOutLabel = `${audioInputIndices[0]}:a`;
		if (audioInputIndices.length > 1) {
			const audioIn = audioInputIndices.map((i) => `[${i}:a]`).join("");
			filters.push(
				`${audioIn}amix=inputs=${audioInputIndices.length}:duration=longest:dropout_transition=2:normalize=0[aout]`
			);
			audioOutLabel = "[aout]";
		}

		if (filters.length > 0) {
			args.push("-filter_complex", filters.join(";"));
		}

		// ── VIDEO MAP + ENCODE ─────────────────────────────────────────────
		const videoMapLabel = filters.some((f) => f.includes("[vout]")) ? "[vout]" : "0:v";
		args.push("-map", videoMapLabel);
		args.push("-c:v", enc.codec, ...enc.extra);
		args.push(
			"-g", String(gop),
			"-keyint_min", String(gop),
			"-force_key_frames", `expr:gte(t,n_forced*${segSec})`,
			"-b:v", `${o.bitrate}k`,
		);
		if (!isNvencZeroCopy) args.push("-pix_fmt", "yuv420p");
		// CFR: lock output to a constant frame cadence so players never see
		// variable-timestamp stutter regardless of what the capture source
		// delivered. This is what OBS's "Common FPS Values" mode does.
		args.push("-fps_mode:v", "cfr", "-r", String(o.fps));

		// ── AUDIO MAP + ENCODE ─────────────────────────────────────────────
		args.push("-map", audioOutLabel.startsWith("[") ? audioOutLabel : `${audioOutLabel}`);
		args.push("-c:a", "aac", "-b:a", `${o.audioBitrate}k`, "-ac", "2", "-ar", "48000");

		// ── SEGMENT MUXER ─────────────────────────────────────────────────
		const wrapCount = 9000;
		args.push(
			"-f", "segment",
			"-segment_time", String(segSec),
			"-reset_timestamps", "1",
			"-segment_wrap", String(wrapCount),
			path.join(this.opts.bufferDir, "seg_%05d.mp4")
		);

		// stdout: "ignore" — ffmpeg writes nothing useful to stdout in segment
		// mode (progress goes to stderr). Keeping it as "pipe" without consuming
		// it causes Node to buffer it indefinitely; on long recordings that
		// buffer pressure eventually emits a stream error.
		// stdin: "pipe" — needed for the graceful "q" quit signal, but we must
		// attach an error listener immediately or any write to a broken pipe
		// (process already exiting) becomes an unhandled error event that
		// crashes the main process. This is the Socket.emit/addChunk/Readable.push
		// stream error that was killing the build on Windows.
		const proc = spawn(this.opts.ffmpegPath, args, {
			windowsHide: true,
			stdio: ["pipe", "ignore", "pipe"],
		});
		this.proc = proc;

		// Attach an error listener to stdin immediately — before any write.
		// Without this, a write to a closed/broken pipe emits "error" on the
		// stream with no listener, which Node treats as an uncaught exception.
		proc.stdin?.on("error", () => { /* graceful stop only — ignore pipe errors */ });

		proc.stderr!.on("data", (chunk: Buffer) => {
			const text = chunk.toString();
			this.stderrTail.push(...text.split("\n").filter(Boolean));
			if (this.stderrTail.length > 100) this.stderrTail.splice(0, this.stderrTail.length - 100);
			// First successful "frame=" line means ffmpeg is actively encoding.
			if (this.state === "starting" && /frame=/.test(text)) this.setState("recording");
		});

		proc.on("error", (err) => {
			this.handleUnexpectedExit(`spawn error: ${err.message}`);
		});

		proc.on("exit", (code, signal) => {
			this.proc = null;
			if (this.manualStop) {
				this.setState("idle");
				return;
			}
			this.handleUnexpectedExit(`ffmpeg exited (code=${code}, signal=${signal})`);
		});
	}

	// ── Bounded watchdog restart — replaces the old unbounded fallback loop ──
	private handleUnexpectedExit(detail: string) {
		const now = Date.now();
		this.restartTimestamps = this.restartTimestamps.filter((t) => now - t < RESTART_WINDOW_MS);
		this.restartTimestamps.push(now);

		// ddagrab passed the static "-filters" capability check but is still
		// failing at runtime (e.g. no compatible GPU/driver in this session) —
		// downgrade to gdigrab once, mirroring OBS's own capture fallback
		// chain, instead of burning all restart attempts on a method that
		// isn't going to work on this machine.
		if (this.opts?.captureMethod === "ddagrab" && this.restartTimestamps.length === 2) {
			this.opts = { ...this.opts, captureMethod: "gdigrab" };
			this.restartTimestamps = [];
			this.setState("starting", `ddagrab failed at runtime, falling back to gdigrab: ${detail}`);
			setTimeout(() => { if (!this.manualStop) this.spawnFfmpeg(); }, 500);
			return;
		}

		// The "-encoders" capability check only reflects what ffmpeg was built
		// with, not what hardware is actually present — a build with NVENC
		// compiled in will still fail at runtime on a non-NVIDIA machine. Step
		// down the same NVENC -> QSV -> AMF -> x264 chain OBS's own encoder
		// auto-detection falls back through, instead of erroring out on a
		// hardware encoder that simply isn't usable on this machine.
		const fallbackChain = ["NVENC (NVIDIA)", "QuickSync (Intel)", "AMF (AMD)", "x264 (Software)"];
		const currentIdx = this.opts ? fallbackChain.indexOf(this.opts.encoder ?? "") : -1;
		if (currentIdx >= 0 && currentIdx < fallbackChain.length - 1 && this.restartTimestamps.length === 2) {
			const nextEncoder = fallbackChain[currentIdx + 1];
			this.opts = { ...this.opts!, encoder: nextEncoder };
			this.restartTimestamps = [];
			this.setState("starting", `${fallbackChain[currentIdx]} failed at runtime, falling back to ${nextEncoder}: ${detail}`);
			setTimeout(() => { if (!this.manualStop) this.spawnFfmpeg(); }, 500);
			return;
		}

		if (this.restartTimestamps.length > MAX_RESTARTS) {
			this.setState("error", `Capture failed repeatedly and was stopped: ${detail}`);
			if (this.pruneTimer) clearInterval(this.pruneTimer);
			this.pruneTimer = null;
			return;
		}

		const attempt = this.restartTimestamps.length;
		const backoffMs = Math.min(1000 * 2 ** (attempt - 1), 8000);
		this.setState("starting", `Restarting capture (attempt ${attempt}/${MAX_RESTARTS}) after: ${detail}`);
		setTimeout(() => {
			if (!this.manualStop) this.spawnFfmpeg();
		}, backoffMs);
	}

	// ── Stop ─────────────────────────────────────────────────────────────────
	async stop(): Promise<void> {
		this.manualStop = true;
		if (this.pruneTimer) {
			clearInterval(this.pruneTimer);
			this.pruneTimer = null;
		}
		if (!this.proc) {
			this.setState("idle");
			return;
		}
		const proc = this.proc;
		this.proc = null;

		await new Promise<void>((resolve) => {
			const done = () => { clearTimeout(hardKillTimer); clearTimeout(sigkillTimer); resolve(); };
			proc.once("exit", done);

			// Step 1: ask ffmpeg to flush and quit gracefully via stdin "q".
			// This is the same signal OBS sends on its "Stop Recording" path —
			// it lets ffmpeg finish the current segment's moof/moov atoms so
			// the last few seconds of footage aren't truncated.
			// The stdin error listener on the stream (attached at spawn time)
			// eats any broken-pipe error, so this can't crash the process.
			try {
				proc.stdin?.write("q\n");
				proc.stdin?.end();
			} catch {
				// already closed — fall through to SIGTERM below
			}

			// Step 2: if ffmpeg hasn't exited within 3s, send SIGTERM.
			// On Windows, Node maps SIGTERM to TerminateProcess() which is
			// immediate but gives ffmpeg no chance to flush — acceptable here
			// since the 3s window already gave it time to close gracefully.
			const hardKillTimer = setTimeout(() => {
				try { proc.kill("SIGTERM"); } catch { /* already gone */ }
			}, 3000);

			// Step 3: absolute last resort — if still alive after 5s total,
			// force-kill. Should never be reached in practice.
			const sigkillTimer = setTimeout(() => {
				try { proc.kill(); } catch { /* already gone */ }
				resolve();
			}, 5000);
		});

		this.wasapiCapture.stop();
		this.setState("idle");
	}

	// ── List current buffered segments, oldest first ────────────────────────
	private listSegments(): SegmentInfo[] {
		if (!this.opts) return [];
		try {
			return fs
				.readdirSync(this.opts.bufferDir)
				.filter((f) => f.startsWith("seg_") && f.endsWith(".mp4"))
				.map((f) => {
					const full = path.join(this.opts!.bufferDir, f);
					return { file: full, mtimeMs: fs.statSync(full).mtimeMs };
				})
				.sort((a, b) => a.mtimeMs - b.mtimeMs);
		} catch {
			return [];
		}
	}

	private pruneOldSegments() {
		if (!this.opts) return;
		const segs = this.listSegments();
		const segSec = this.opts.segmentSeconds ?? DEFAULT_SEGMENT_SECONDS;
		const keepCount = Math.ceil(this.opts.bufferDuration / segSec) + 3; // headroom
		if (segs.length > keepCount) {
			for (const s of segs.slice(0, segs.length - keepCount)) {
				try { fs.unlinkSync(s.file); } catch { /* ignore */ }
			}
		}
	}

	// ── Save last N seconds via stream-copy concat — instant, keyframe-clean ─
	async saveClip(seconds: number, outputPath: string): Promise<string> {
		if (!this.opts) throw new Error("Capture not initialized");
		const segs = this.listSegments();
		if (!segs.length) {
			const hint =
				this.state !== "recording"
					? ` (capture state: ${this.state} — wait for it to reach "recording" before saving)`
					: " (no segments written yet — wait a few seconds after starting, or check diagnostics)";
			const tail = this.stderrTail.slice(-5).join(" | ");
			throw new Error(`No buffered footage yet${hint}${tail ? ` — ffmpeg: ${tail}` : ""}`);
		}

		const segSec = this.opts.segmentSeconds ?? DEFAULT_SEGMENT_SECONDS;
		const neededCount = Math.max(1, Math.ceil(seconds / segSec) + 1); // +1 segment headroom
		// Drop the very last segment if it's still being written (size may be
		// growing); ffmpeg's segment muxer finalizes a segment's moov atom only
		// once the next one starts, so the newest file can be briefly invalid.
		const stable = segs.length > 1 ? segs.slice(0, -1) : segs;
		const chosen = stable.slice(Math.max(0, stable.length - neededCount));
		if (!chosen.length) throw new Error("Not enough buffered footage yet");

		const listPath = path.join(os.tmpdir(), `clipsta_concat_${Date.now()}.txt`);
		const listContent = chosen.map((s) => `file '${s.file.replace(/'/g, "'\\''")}'`).join("\n");
		await fs.promises.writeFile(listPath, listContent, "utf-8");

		const args = [
			"-y", "-hide_banner", "-loglevel", "warning",
			"-f", "concat", "-safe", "0",
			"-i", listPath,
			"-c", "copy",
			"-movflags", "+faststart",
			outputPath,
		];

		await new Promise<void>((resolve, reject) => {
			execFile(this.opts!.ffmpegPath, args, { timeout: 60000 }, (err, _stdout, stderr) => {
				fs.unlink(listPath, () => {});
				if (err) reject(new Error(`Concat failed: ${stderr?.split("\n").slice(-3).join(" ") || err.message}`));
				else resolve();
			});
		});

		return outputPath;
	}
}

export const captureEngine = new CaptureEngine();
