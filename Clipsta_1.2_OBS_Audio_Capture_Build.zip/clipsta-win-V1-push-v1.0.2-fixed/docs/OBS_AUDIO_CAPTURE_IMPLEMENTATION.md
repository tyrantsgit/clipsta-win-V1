# Clipsta 1.2 OBS Audio Capture Migration

Audio pipeline target:

Windows WASAPI -> libobs audio source -> OBS mixer -> Clipsta replay buffer -> AAC MP4 mux

Replace FFmpeg-only audio capture with OBS sources:
- wasapi-output-capture for desktop/game audio
- wasapi-input-capture for microphone

Settings:
- 48kHz
- stereo
- AAC 320kbps
- separate desktop/mic tracks

Required native dependencies:
- libobs
- OBS core audio modules
- WASAPI capture plugin
