// ─────────────────────────────────────────────────────────────────────────────
// CaptureEngine — OBS-style continuous segmented capture + instant replay save
//
// WHY THIS EXISTS
// The old pipeline used the browser's MediaRecorder API on a getDisplayMedia
// stream, sliced into 100ms chunks held in renderer memory. That approach has
// a structural flaw: MediaRecorder/Chromium decides keyframe placement on its
// own (no exposed GOP control), so slicing the in-memory chunk buffer to make
// a "last N seconds" clip very often cuts the window *before* the nearest
// keyframe. The resulting webm then has delta frames with no reference frame
// to decode against — which is exactly the choppy/corrupted playback bug.
// It also ties capture to the renderer's video element, so minimizing or
// backgrounding the window can starve/crash the encode pipeline.
//
// OBS solves this in libobs's replay-buffer module by encoding continuously
// with a fixed keyframe interval and only ever flushing whole, independently
// decodable GOPs when a replay is saved — never a partial GOP. We port that
// exact strategy using ffmpeg (already bundled in Clipsta) instead of libobs:
//
//   1. A single long-running ffmpeg process captures the desktop and loopback
//      audio (dshow), continuously writing fixed-length segment files via the
//      `segment` muxer, with a forced keyframe at the start of every segment
//      (-g / -force_key_frames). Every segment is therefore a fully
//      self-contained, cleanly decodable unit — same guarantee OBS gives its
//      GOPs.
//
//      Capture method: OBS's default Windows "Display Capture" source uses
//      the DXGI Desktop Duplication API — a GPU-side capture path, the same
//      one NVIDIA ShadowPlay uses. FFmpeg exposes this as the `ddagrab`
//      filter. We use it as the primary capture path and only fall back to
//      `gdigrab` (CPU/GDI bitblt) when ddagrab isn't available in the bundled
//      ffmpeg build. This matters: gdigrab is a CPU-bound blit loop that
//      reliably struggles to sustain 60fps, especially at 1080p+ — no amount
//      of downstream CFR correction fixes a source that can't deliver enough
//      real frames per second in the first place. ddagrab captures GPU
//      textures directly and is the actual fix for "fps not smooth."
//   2. A rolling buffer directory holds the last `bufferDuration` seconds of
//      segments; older segments are pruned on a timer.
//   3. "Save last N seconds" = pick the trailing segments covering N seconds
//      and stream-copy-concat them (-c copy) into the final MP4. No
//      re-encode, instant, and frame-accurate because every cut point is a
//      keyframe boundary by construction. This is the direct equivalent of
//      OBS's "Save Replay".
//   4. The watchdog restarts ffmpeg on unexpected exit with capped retries
//      and exponential backoff, instead of the old unbounded fallback loop
//      that could spin forever.
// ─────────────────────────────────────────────────────────────────────────────

import { spawn, execFile, ChildProcessWithoutNullStreams } from "child_process";
import fs from "fs";
import path from "path";
import os from "os";

export type CaptureState = "idle" | "starting" | "recording" | "stopping" | "error";
export type CaptureMethod = "ddagrab" | "gdigrab";

export interface CaptureOptions {
	ffmpegPath: string;
	bufferDir: string;
	fps: number;
	resolution: string; // "480p" | "720p" | "1080p" | "1440p" | "4k"
	encoder?: string; // "auto" | "NVENC (NVIDIA)" | "AMF (AMD)" | "QuickSync (Intel)" | "HEVC (H.265)" | "x264 (Software)"
	bitrate: number; // kbps
	audioBitrate: number; // kbps
	bufferDuration: number; // seconds of rolling buffer to retain
	desktopAudioDeviceName?: string | null; // dshow loopback-capable device name for desktop/game audio; null = not captured
	micAudioDeviceName?: string | null; // dshow device name for microphone; null = not captured
	monitorIndex?: number; // which display to grab (output_idx for ddagrab, offset for gdigrab)
	segmentSeconds?: number; // GOP/segment length; default 4s — matches typical OBS keyframe interval
	captureMethod?: CaptureMethod; // force a method; omit to auto-detect (ddagrab preferred)
}

interface SegmentInfo {
	file: string;
	mtimeMs: number;
}

const DEFAULT_SEGMENT_SECONDS = 4;
const MAX_RESTARTS = 4;
const RESTART_WINDOW_MS = 60_000;

function resolutionToHeight(res: string): number | null {
	const map: Record<string, number> = { "480p": 480, "720p": 720, "1080p": 1080, "1440p": 1440, "4k": 2160 };
	return map[res] ?? null;
}

// ── Hardware capabilities are probed once per app session and cached ─────────
let cachedCaptureMethod: CaptureMethod | null = null;
let cachedBestEncoder: string | null = null;

async function detectCaptureMethod(ffmpegPath: string): Promise<CaptureMethod> {
	if (cachedCaptureMethod) return cachedCaptureMethod;
	const supported = await new Promise<boolean>((resolve) => {
		execFile(ffmpegPath, ["-hide_banner", "-filters"], { timeout: 8000 }, (_err, stdout) => {
			resolve(/\bddagrab\b/.test(stdout || ""));
		});
	});
	cachedCaptureMethod = supported ? "ddagrab" : "gdigrab";
	return cachedCaptureMethod;
}

// Mirrors OBS's own "Simple Output" hardware-encoder auto-detection: prefer
// the GPU vendor's encoder (NVENC, then QuickSync, then AMF) and only fall
// back to software x264 if no hardware path is available. This is also what
// gives ShadowPlay-comparable smoothness/perf — software encode under load
// is a common secondary cause of dropped/uneven frames even once capture
// itself is fast.
async function detectBestEncoder(ffmpegPath: string): Promise<string> {
	if (cachedBestEncoder) return cachedBestEncoder;
	const available = await new Promise<string>((resolve) => {
		execFile(ffmpegPath, ["-hide_banner", "-encoders"], { timeout: 8000 }, (_err, stdout) => {
			resolve(stdout || "");
		});
	});
	if (/\bh264_nvenc\b/.test(available)) cachedBestEncoder = "NVENC (NVIDIA)";
	else if (/\bh264_qsv\b/.test(available)) cachedBestEncoder = "QuickSync (Intel)";
	else if (/\bh264_amf\b/.test(available)) cachedBestEncoder = "AMF (AMD)";
	else cachedBestEncoder = "x264 (Software)";
	return cachedBestEncoder;
}

function encoderToFfmpegArgs(encoder?: string): { codec: string; extra: string[] } {
	switch (encoder) {
		case "NVENC (NVIDIA)":
			// p4/vbr/cq19 mirrors NVIDIA ShadowPlay's "High Quality" tuning more
			// closely than a faster preset + higher cq would; the GPU has plenty
			// of headroom for this on anything ShadowPlay itself targets.
			return { codec: "h264_nvenc", extra: ["-preset", "p4", "-rc", "vbr", "-cq", "19", "-bf", "3"] };
		case "AMF (AMD)":
			return { codec: "h264_amf", extra: ["-quality", "balanced", "-rc", "cqp", "-qp_i", "20", "-qp_p", "20"] };
		case "QuickSync (Intel)":
			return { codec: "h264_qsv", extra: ["-preset", "medium", "-global_quality", "20"] };
		case "HEVC (H.265)":
			return { codec: "libx265", extra: ["-preset", "veryfast", "-crf", "21"] };
		case "x264 (Software)":
		default:
			return { codec: "libx264", extra: ["-preset", "veryfast", "-crf", "19"] };
	}
}

export class CaptureEngine {
	private proc: ChildProcessWithoutNullStreams | null = null;
	private state: CaptureState = "idle";
	private opts: CaptureOptions | null = null;
	private pruneTimer: NodeJS.Timeout | null = null;
	private restartTimestamps: number[] = [];
	private stderrTail: string[] = [];
	private onStateChange: ((s: CaptureState, detail?: string) => void) | null = null;
	private manualStop = false;

	setStateListener(cb: (s: CaptureState, detail?: string) => void) {
		this.onStateChange = cb;
	}

	getState(): CaptureState {
		return this.state;
	}

	getDiagnostics() {
		return {
			state: this.state,
			stderrTail: this.stderrTail.slice(-20),
			captureMethod: this.opts?.captureMethod,
			encoder: this.opts?.encoder,
		};
	}

	private setState(s: CaptureState, detail?: string) {
		this.state = s;
		this.onStateChange?.(s, detail);
	}

	// ── List available dshow audio devices (best-effort parse) ────────────────
	// Best-effort pick of a loopback-capable dshow audio device for desktop/
	// game audio. ffmpeg's dshow has no driverless WASAPI loopback (unlike
	// OBS's native Desktop Audio source), so this only works if the machine
	// exposes one of these — Windows' built-in "Stereo Mix" (disabled by
	// default on many drivers, but present on a lot of onboard audio), or a
	// virtual audio cable the user has installed (VB-Cable, VoiceMeeter).
	// Returns null if none found, so callers can surface that desktop audio
	// genuinely isn't capturable on this machine rather than silently
	// substituting mic audio for it.
	static async detectDesktopLoopbackDevice(ffmpegPath: string): Promise<string | null> {
		const devices = await CaptureEngine.listAudioDevices(ffmpegPath);
		const loopbackPatterns = [/stereo mix/i, /loopback/i, /what u hear/i, /cable output/i, /virtual.*cable/i, /voicemeeter/i];
		for (const pattern of loopbackPatterns) {
			const match = devices.find((d) => pattern.test(d));
			if (match) return match;
		}
		return null;
	}

	static async listAudioDevices(ffmpegPath: string): Promise<string[]> {
		return new Promise((resolve) => {
			execFile(
				ffmpegPath,
				["-hide_banner", "-list_devices", "true", "-f", "dshow", "-i", "dummy"],
				{ timeout: 10000 },
				(_err, _stdout, stderr) => {
					const names: string[] = [];
					const re = /"([^"]+)"\s*\(audio\)/g;
					let m: RegExpExecArray | null;
					while ((m = re.exec(stderr || "")) !== null) names.push(m[1]);
					resolve(names);
				}
			);
		});
	}

	// ── Start continuous capture ────────────────────────────────────────────
	async start(opts: CaptureOptions): Promise<void> {
		if (this.state === "recording" || this.state === "starting") return;
		this.manualStop = false;
		this.restartTimestamps = [];

		// Resolve "auto" picks once, up front, the same way OBS's simple output
		// mode auto-detects a hardware encoder and Display Capture defaults to
		// Desktop Duplication: prefer ddagrab (DXGI Desktop Duplication — the
		// GPU-side capture path ShadowPlay also uses) over gdigrab, and prefer
		// a hardware encoder over software x264 when one is actually present.
		const resolvedMethod = opts.captureMethod ?? (await detectCaptureMethod(opts.ffmpegPath));
		const resolvedEncoder =
			!opts.encoder || opts.encoder === "auto" ? await detectBestEncoder(opts.ffmpegPath) : opts.encoder;
		this.opts = { ...opts, captureMethod: resolvedMethod, encoder: resolvedEncoder };

		await fs.promises.mkdir(opts.bufferDir, { recursive: true });
		this.clearBufferDir(opts.bufferDir);
		this.setState("starting", `Using ${resolvedMethod} capture + ${resolvedEncoder} encoder`);
		this.spawnFfmpeg();
		this.pruneTimer = setInterval(() => this.pruneOldSegments(), 15_000);
	}

	private clearBufferDir(dir: string) {
		try {
			for (const f of fs.readdirSync(dir)) {
				if (f.startsWith("seg_")) fs.unlinkSync(path.join(dir, f));
			}
		} catch {
			/* ignore */
		}
	}

	private spawnFfmpeg() {
		if (!this.opts) return;
		const o = this.opts;
		const segSec = o.segmentSeconds ?? DEFAULT_SEGMENT_SECONDS;
		const enc = encoderToFfmpegArgs(o.encoder);
		const height = resolutionToHeight(o.resolution);

		const args: string[] = ["-y", "-hide_banner", "-loglevel", "warning"];
		const method = o.captureMethod ?? "gdigrab";

		if (method === "ddagrab") {
			// ── Video input: ddagrab — DXGI Desktop Duplication API. This is the
			// GPU-side capture path: OBS's "Display Capture" source uses the same
			// API, as does NVIDIA ShadowPlay. It captures compositor output
			// directly off the GPU instead of CPU-blitting the screen the way
			// gdigrab does, so it can actually sustain 60fps reliably — this is
			// the real fix for dropped/uneven frame rate, not just a downstream
			// timestamp correction.
			// ddagrab yields hardware (D3D11) frames; hwdownload+format=bgra
			// brings them back to a normal frame format so the rest of the
			// pipeline (scale/encode) is unchanged and works with any encoder,
			// hardware or software.
			const outputIdx = o.monitorIndex ?? 0;
			args.push(
				"-f", "lavfi", "-i",
				`ddagrab=output_idx=${outputIdx}:framerate=${o.fps}:draw_mouse=1`
			);
		} else {
			// ── Fallback: gdigrab (CPU/GDI bitblt). Used only when the bundled
			// ffmpeg build lacks ddagrab support, or ddagrab failed at runtime
			// (see handleUnexpectedExit's automatic downgrade).
			args.push("-f", "gdigrab", "-framerate", String(o.fps), "-draw_mouse", "1");
			// thread_queue_size gives ffmpeg's demuxer thread enough headroom to
			// absorb brief stalls (encoder catching up, disk I/O, etc.) without
			// dropping frames at the input stage.
			args.push("-thread_queue_size", "1024");
			args.push("-i", "desktop");
		}

		// ── Audio inputs: desktop/game loopback and microphone are genuinely
		// separate sources, captured separately and mixed if both are wanted.
		// (Previously this engine only ever read `audioInputDeviceId` — which
		// is the *microphone* selector — into the single audio slot, so
		// desktop/game audio was never actually captured: if you'd set up a
		// mic, you got mic audio; desktop audio had no path into the encode
		// at all, regardless of settings.)
		//
		// Windows/ffmpeg caveat: `dshow` has no driverless loopback capture —
		// there's no built-in WASAPI loopback indev the way OBS's native
		// "Desktop Audio" source has. Desktop/game audio capture needs a
		// loopback-capable dshow device name (Windows' built-in "Stereo Mix"
		// if the audio driver exposes it, or a virtual audio cable). That
		// device name is resolved by the caller (see index.ts) via
		// CaptureEngine.listAudioDevices() and passed in as
		// desktopAudioDeviceName; if none is found/configured, desktop audio
		// is silently skipped rather than mislabeling mic audio as desktop.
		const audioInputs: number[] = []; // ffmpeg input indices that are audio
		let nextInputIdx = 1; // 0 is always the video input
		if (o.desktopAudioDeviceName) {
			args.push("-thread_queue_size", "1024", "-f", "dshow", "-i", `audio=${o.desktopAudioDeviceName}`);
			audioInputs.push(nextInputIdx++);
		}
		if (o.micAudioDeviceName) {
			args.push("-thread_queue_size", "1024", "-f", "dshow", "-i", `audio=${o.micAudioDeviceName}`);
			audioInputs.push(nextInputIdx++);
		}
		if (audioInputs.length === 0) {
			args.push("-f", "lavfi", "-i", "anullsrc=channel_layout=stereo:sample_rate=48000");
			audioInputs.push(nextInputIdx++);
		}

		// ── Video encode: fixed GOP = segment length, forced keyframe at every
		// segment boundary. This is the load-bearing fix: every segment is a
		// standalone, independently decodable unit, same guarantee OBS's
		// replay buffer relies on.
		const gop = segSec * o.fps;
		// ddagrab yields D3D11 hardware frames. NVENC can ingest those directly
		// (this is ffmpeg's own documented zero-copy ddagrab pattern) — no need
		// to round-trip GPU->CPU->GPU via hwdownload first. Forcing that
		// round-trip on every frame (the previous behavior) is real per-frame
		// CPU work that can make the encoder fall behind at 1080p60+, and a
		// falling-behind encoder is exactly what produces duplicated/dropped
		// frames — i.e. the choppy playback being reported, even though the
		// capture side looks fine. Only pay for hwdownload when the encoder
		// genuinely needs CPU-side frames (software x264/x265, or QSV/AMF
		// which expect their own hw frame types, not D3D11VA).
		const isZeroCopyNvenc = method === "ddagrab" && enc.codec === "h264_nvenc";
		const vf: string[] = [];
		if (method === "ddagrab" && !isZeroCopyNvenc) vf.push("hwdownload", "format=bgra");
		if (height) vf.push(`scale=-2:${height}`);

		args.push("-map", "0:v", "-c:v", enc.codec, ...enc.extra);
		args.push(
			"-g", String(gop),
			"-keyint_min", String(gop),
			"-force_key_frames", `expr:gte(t,n_forced*${segSec})`,
			"-b:v", `${o.bitrate}k`
		);
		if (!isZeroCopyNvenc) args.push("-pix_fmt", "yuv420p");
		args.push(
			// ── CFR enforcement — fixes "fps dropping / choppy playback" ──
			// gdigrab hands ffmpeg frames at whatever cadence the desktop actually
			// updated (naturally variable frame rate / VFR), tagged with the real
			// capture timestamps. Muxing that as-is means the output's *declared*
			// fps and its *actual* per-frame timing don't match — most players and
			// every video editor assume CFR, so they end up either skipping ahead
			// or visibly stuttering trying to reconcile the mismatch. This is
			// exactly the kind of source-timing problem OBS's "Common FPS Values"
			// recording mode exists to normalize away.
			// "-fps_mode cfr" (the modern replacement for the deprecated -vsync 1)
			// duplicates or drops frames as needed so the encoded stream is a
			// perfectly even, locked cadence at the declared rate — smooth
			// constant-fps playback with no variable-timestamp stutter.
			"-fps_mode:v", "cfr",
			"-r", String(o.fps)
		);
		if (vf.length) args.push("-vf", vf.join(","));

		// ── Audio map: mix desktop + mic when both are present, otherwise map
		// the single available source directly. amix's default would halve
		// each input's volume when summing two sources; "normalize=0" keeps
		// the perceived game/mic levels matching what was actually captured
		// instead of mystery-quietening everything by half.
		if (audioInputs.length > 1) {
			const filterInputs = audioInputs.map((i) => `[${i}:a]`).join("");
			args.push(
				"-filter_complex",
				`${filterInputs}amix=inputs=${audioInputs.length}:duration=longest:dropout_transition=2:normalize=0[aout]`,
				"-map", "[aout]"
			);
		} else {
			args.push("-map", `${audioInputs[0]}:a`);
		}

		// ── Audio encode (built above from desktop loopback + mic, mixed if both)
		args.push("-c:a", "aac", "-b:a", `${o.audioBitrate}k`, "-ac", "2", "-ar", "48000");

		// ── Segment muxer: GOP-aligned, numbered files for reliable ordering.
		// NOTE: an earlier version used "-strftime 1" with a "%f" (microsecond)
		// token in the filename. "%f" is not a valid strftime specifier in
		// ffmpeg's implementation (or Windows' CRT), so every segment within
		// the same second collided on the same filename and overwrote/failed
		// to write — leaving the buffer directory empty and causing
		// "no buffered footage" on save. A plain incrementing index has no
		// such collision risk. We don't rely on the filename for ordering
		// anyway (listSegments() sorts by mtime), so this is strictly simpler
		// and more robust. -segment_wrap caps disk usage as a backstop to the
		// pruning timer.
		const wrapCount = 9000; // ~10hr of buffer history at 4s segments before wrap
		args.push(
			"-f", "segment",
			"-segment_time", String(segSec),
			"-reset_timestamps", "1",
			"-segment_wrap", String(wrapCount),
			path.join(this.opts.bufferDir, "seg_%05d.mp4")
		);

		const proc = spawn(this.opts.ffmpegPath, args, { windowsHide: true, stdio: ["pipe", "pipe", "pipe"] });
		this.proc = proc;

		proc.stderr.on("data", (chunk: Buffer) => {
			const text = chunk.toString();
			this.stderrTail.push(...text.split("\n").filter(Boolean));
			if (this.stderrTail.length > 100) this.stderrTail.splice(0, this.stderrTail.length - 100);
			// First successful "frame=" line means ffmpeg is actively encoding.
			if (this.state === "starting" && /frame=/.test(text)) this.setState("recording");
		});

		proc.on("error", (err) => {
			this.handleUnexpectedExit(`spawn error: ${err.message}`);
		});

		proc.on("exit", (code, signal) => {
			this.proc = null;
			if (this.manualStop) {
				this.setState("idle");
				return;
			}
			this.handleUnexpectedExit(`ffmpeg exited (code=${code}, signal=${signal})`);
		});
	}

	// ── Bounded watchdog restart — replaces the old unbounded fallback loop ──
	private handleUnexpectedExit(detail: string) {
		const now = Date.now();
		this.restartTimestamps = this.restartTimestamps.filter((t) => now - t < RESTART_WINDOW_MS);
		this.restartTimestamps.push(now);

		// ddagrab passed the static "-filters" capability check but is still
		// failing at runtime (e.g. no compatible GPU/driver in this session) —
		// downgrade to gdigrab once, mirroring OBS's own capture fallback
		// chain, instead of burning all restart attempts on a method that
		// isn't going to work on this machine.
		if (this.opts?.captureMethod === "ddagrab" && this.restartTimestamps.length === 2) {
			this.opts = { ...this.opts, captureMethod: "gdigrab" };
			this.restartTimestamps = [];
			this.setState("starting", `ddagrab failed at runtime, falling back to gdigrab: ${detail}`);
			setTimeout(() => { if (!this.manualStop) this.spawnFfmpeg(); }, 500);
			return;
		}

		// The "-encoders" capability check only reflects what ffmpeg was built
		// with, not what hardware is actually present — a build with NVENC
		// compiled in will still fail at runtime on a non-NVIDIA machine. Step
		// down the same NVENC -> QSV -> AMF -> x264 chain OBS's own encoder
		// auto-detection falls back through, instead of erroring out on a
		// hardware encoder that simply isn't usable on this machine.
		const fallbackChain = ["NVENC (NVIDIA)", "QuickSync (Intel)", "AMF (AMD)", "x264 (Software)"];
		const currentIdx = this.opts ? fallbackChain.indexOf(this.opts.encoder ?? "") : -1;
		if (currentIdx >= 0 && currentIdx < fallbackChain.length - 1 && this.restartTimestamps.length === 2) {
			const nextEncoder = fallbackChain[currentIdx + 1];
			this.opts = { ...this.opts!, encoder: nextEncoder };
			this.restartTimestamps = [];
			this.setState("starting", `${fallbackChain[currentIdx]} failed at runtime, falling back to ${nextEncoder}: ${detail}`);
			setTimeout(() => { if (!this.manualStop) this.spawnFfmpeg(); }, 500);
			return;
		}

		if (this.restartTimestamps.length > MAX_RESTARTS) {
			this.setState("error", `Capture failed repeatedly and was stopped: ${detail}`);
			if (this.pruneTimer) clearInterval(this.pruneTimer);
			this.pruneTimer = null;
			return;
		}

		const attempt = this.restartTimestamps.length;
		const backoffMs = Math.min(1000 * 2 ** (attempt - 1), 8000);
		this.setState("starting", `Restarting capture (attempt ${attempt}/${MAX_RESTARTS}) after: ${detail}`);
		setTimeout(() => {
			if (!this.manualStop) this.spawnFfmpeg();
		}, backoffMs);
	}

	// ── Stop ─────────────────────────────────────────────────────────────────
	async stop(): Promise<void> {
		this.manualStop = true;
		if (this.pruneTimer) {
			clearInterval(this.pruneTimer);
			this.pruneTimer = null;
		}
		if (!this.proc) {
			this.setState("idle");
			return;
		}
		const proc = this.proc;
		await new Promise<void>((resolve) => {
			const timeout = setTimeout(() => {
				try { proc.kill("SIGTERM"); } catch { /* ignore */ }
				resolve();
			}, 4000);
			proc.once("exit", () => { clearTimeout(timeout); resolve(); });
			// "q" requests a graceful ffmpeg shutdown — flushes the in-progress
			// segment instead of truncating it mid-GOP.
			try { proc.stdin.write("q"); } catch { /* ignore */ }
		});
		this.setState("idle");
	}

	// ── List current buffered segments, oldest first ────────────────────────
	private listSegments(): SegmentInfo[] {
		if (!this.opts) return [];
		try {
			return fs
				.readdirSync(this.opts.bufferDir)
				.filter((f) => f.startsWith("seg_") && f.endsWith(".mp4"))
				.map((f) => {
					const full = path.join(this.opts!.bufferDir, f);
					return { file: full, mtimeMs: fs.statSync(full).mtimeMs };
				})
				.sort((a, b) => a.mtimeMs - b.mtimeMs);
		} catch {
			return [];
		}
	}

	private pruneOldSegments() {
		if (!this.opts) return;
		const segs = this.listSegments();
		const segSec = this.opts.segmentSeconds ?? DEFAULT_SEGMENT_SECONDS;
		const keepCount = Math.ceil(this.opts.bufferDuration / segSec) + 3; // headroom
		if (segs.length > keepCount) {
			for (const s of segs.slice(0, segs.length - keepCount)) {
				try { fs.unlinkSync(s.file); } catch { /* ignore */ }
			}
		}
	}

	// ── Save last N seconds via stream-copy concat — instant, keyframe-clean ─
	async saveClip(seconds: number, outputPath: string): Promise<string> {
		if (!this.opts) throw new Error("Capture not initialized");
		const segs = this.listSegments();
		if (!segs.length) {
			const hint =
				this.state !== "recording"
					? ` (capture state: ${this.state} — wait for it to reach "recording" before saving)`
					: " (no segments written yet — wait a few seconds after starting, or check diagnostics)";
			const tail = this.stderrTail.slice(-5).join(" | ");
			throw new Error(`No buffered footage yet${hint}${tail ? ` — ffmpeg: ${tail}` : ""}`);
		}

		const segSec = this.opts.segmentSeconds ?? DEFAULT_SEGMENT_SECONDS;
		const neededCount = Math.max(1, Math.ceil(seconds / segSec) + 1); // +1 segment headroom
		// Drop the very last segment if it's still being written (size may be
		// growing); ffmpeg's segment muxer finalizes a segment's moov atom only
		// once the next one starts, so the newest file can be briefly invalid.
		const stable = segs.length > 1 ? segs.slice(0, -1) : segs;
		const chosen = stable.slice(Math.max(0, stable.length - neededCount));
		if (!chosen.length) throw new Error("Not enough buffered footage yet");

		const listPath = path.join(os.tmpdir(), `clipsta_concat_${Date.now()}.txt`);
		const listContent = chosen.map((s) => `file '${s.file.replace(/'/g, "'\\''")}'`).join("\n");
		await fs.promises.writeFile(listPath, listContent, "utf-8");

		const args = [
			"-y", "-hide_banner", "-loglevel", "warning",
			"-f", "concat", "-safe", "0",
			"-i", listPath,
			"-c", "copy",
			"-movflags", "+faststart",
			outputPath,
		];

		await new Promise<void>((resolve, reject) => {
			execFile(this.opts!.ffmpegPath, args, { timeout: 60000 }, (err, _stdout, stderr) => {
				fs.unlink(listPath, () => {});
				if (err) reject(new Error(`Concat failed: ${stderr?.split("\n").slice(-3).join(" ") || err.message}`));
				else resolve();
			});
		});

		return outputPath;
	}
}

export const captureEngine = new CaptureEngine();
